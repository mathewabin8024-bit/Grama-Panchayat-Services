# Website and mobile SMS alerts

Administrator-issued safety alerts create one SMS per targeted citizen account using its saved mobile number. Closing an alert updates the website only and never sends a closure SMS. Website warnings remain independent of SMS failures.

## Android phone setup (Traccar)

This option sends through your Android SIM using Traccar SMS Gateway. A paid online SMS provider is not required; your SIM plan and carrier SMS limits still apply.

1. Install the official Traccar SMS Gateway Android app, allow its SMS permission and start its local server. See https://www.traccar.org/http-sms-api/ for the official API documentation.
2. Connect the laptop to the phone hotspot. Keep the gateway running. If a laptop VPN blocks local connections, disconnect it or configure its local-network access.
3. In the project's existing `.env`, set `SMS_BACKEND=traccar`, `TRACCAR_SMS_URL` to the local URL shown by the phone, and `TRACCAR_SMS_KEY` to its local API key. Preserve the other settings. Keep the key private.
4. Restart the web server and worker. `START_DEMO.cmd` starts both. For manual startup, run `python manage.py process_safety_sms --watch` beside the web server.
5. SMS text has no automatic demo prefix. For demonstrations, explicitly write TEST in the instructions and issue the alert to a ward containing only your test account. Check the SMS preview and the phone's Messages app.

The hotspot address can change when the hotspot restarts. Update `TRACCAR_SMS_URL` and restart the server and worker whenever it changes. This adapter accepts local IP URLs only, sends directly without a proxy, and refuses redirects. It uses the phone's default SMS SIM.

A successful response means the phone accepted the send request. The website displays `submitted`; this adapter does not retrieve delivery receipts. Check the phone for the sending result. A timeout or uncertain response is marked `unknown` and is not automatically resent, to avoid duplicate texts.

## What works without internet?

Recipients do not need mobile data or an open website to receive ordinary SMS. They still need functioning cellular service. With the local Android gateway, the laptop needs its local connection to the phone, and the sending phone needs cellular SMS service. Public website hosting and an internet SMS provider are not required. A cellular-network outage can prevent or delay SMS.

## Optional Twilio setup

Set `SMS_BACKEND=twilio`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and either `TWILIO_FROM_NUMBER` or `TWILIO_MESSAGING_SERVICE_SID`. The messaging service takes precedence. Confirm sender, destination and account restrictions with Twilio. The trial tested in this workspace rejected custom message text. Twilio credentials alone do not establish that custom messages can be sent.

## Delivery and operation

The packaged example defaults to `SMS_BACKEND=disabled`. Use `simulation` for a no-send demonstration; simulated rows are never delivered. Backend selection is saved on each SMS record, so switching providers does not send old queues through a different provider. Issue a fresh demonstration alert after configuring a backend.

`SMS_DEFAULT_COUNTRY_CODE=91` treats ten-digit numbers as Indian numbers. International format is preferred. Format validation does not verify ownership or reachability.

The SMS contains the action, area, safe place, instructions and official contact without requiring a website link. Instructions over 350 characters require an explicit SMS summary; safety text is not silently truncated.

The database outbox survives restarts. Pending messages expire after 15 minutes. Closing an alert cancels pending issue messages but cannot retract a message already accepted by the phone/provider. Twilio rate limits retry up to three attempts; ambiguous sends are not retried. Twilio delivery receipts are polled without a public callback, and its submission requests a 15-minute queue validity. The Android adapter cannot enforce expiry after the phone accepts a message.

Refresh the administrator alert page to see masked recipient numbers and status. Submitted does not mean delivered; delivered does not mean read or relocated. Citizen acknowledgement only records that the person clicked the website acknowledgement.

## Local validation

77 automated tests pass, including mocked SMS requests and duplicate prevention. The configured Android gateway accepted one explicitly labelled demo SMS on 1 October 2026 after the hotspot address was updated and VPN blocking was resolved. Recipient handset delivery still needs confirmation. Private credentials and the local citizen database are excluded from the ZIP.

## SMS format

New alerts begin with `Emergency alert: Extreme`, then the actual submission date/time in IST, alert title, area, action, safe place, short SMS instructions (or full instructions when no summary was entered), helpline, and Panchayat signature. The preview shows a timestamp placeholder. The worker stamps the time immediately before each submission and stores the submitted text. This is an ordinary SMS; the heading does not activate a phone cell-broadcast emergency screen.
