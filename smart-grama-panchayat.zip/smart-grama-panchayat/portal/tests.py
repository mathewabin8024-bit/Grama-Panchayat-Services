"""Regression tests for service permissions, document privacy, and workflows."""

import csv
import io
import tempfile
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from reportlab.pdfgen import canvas

from .forms import RequestForm
from .models import Notification, Profile, ServiceRequest, StatusUpdate


User = get_user_model()


class ServiceWorkflowTests(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.media_directory = tempfile.TemporaryDirectory(prefix="panchayat-tests-")
        cls.media_override = override_settings(MEDIA_ROOT=cls.media_directory.name)
        cls.media_override.enable()

    @classmethod
    def tearDownClass(cls):
        cls.media_override.disable()
        cls.media_directory.cleanup()
        super().tearDownClass()

    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user("citizen", "private-citizen@example.com", "TestPassword!47")
        cls.other = User.objects.create_user("other-citizen", "other@example.com", "TestPassword!47")
        cls.official = User.objects.create_user("official", "official@example.com", "TestPassword!47", is_staff=True)
        cls.collector = User.objects.create_user("collector", password="TestPassword!47")
        cls.collector.profile.role = Profile.Role.COLLECTOR
        cls.collector.profile.save(update_fields=["role"])
        cls.other_collector = User.objects.create_user("other-collector", password="TestPassword!47")
        cls.other_collector.profile.role = Profile.Role.COLLECTOR
        cls.other_collector.profile.save(update_fields=["role"])

    def request_record(self, **overrides):
        values = {
            "owner": self.owner,
            "kind": ServiceRequest.Kind.CERTIFICATE,
            "title": "Residence certificate",
            "description": "Private supporting explanation 8ac53",
            "applicant_name": "Test Resident",
            "certificate_type": ServiceRequest.CertificateType.RESIDENCE,
            "address": "Private House 482, Confidential Lane",
            "ward": 3,
            "phone": "9876543210",
        }
        values.update(overrides)
        return ServiceRequest.objects.create(**values)

    def waste_record(self, **overrides):
        values = {
            "kind": ServiceRequest.Kind.WASTE,
            "title": "Waste collection",
            "certificate_type": "",
            "category": "Household waste",
            "preferred_date": timezone.localdate() + timedelta(days=2),
        }
        values.update(overrides)
        return self.request_record(**values)

    def submit_transition(self, record, user, **data):
        self.client.force_login(user)
        return self.client.post(reverse("request_detail", args=[record.pk]), data)

    def test_anonymous_service_details_require_login(self):
        record = self.request_record()
        response = self.client.get(record.get_absolute_url())
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response.url)

    def test_another_citizen_cannot_read_a_request(self):
        record = self.request_record()
        self.client.force_login(self.other)
        response = self.client.get(record.get_absolute_url())
        self.assertIn(response.status_code, [403, 404])
        self.assertNotContains(response, record.address, status_code=response.status_code)

    def test_another_citizen_cannot_download_supporting_document(self):
        record = self.request_record(attachment=SimpleUploadedFile("proof.pdf", b"%PDF-1.4\nprivate proof", content_type="application/pdf"))
        self.client.force_login(self.other)
        response = self.client.get(reverse("attachment_download", args=[record.pk]))
        self.assertIn(response.status_code, [403, 404])

    def test_owner_can_download_supporting_document(self):
        contents = b"%PDF-1.4\nprivate proof"
        record = self.request_record(attachment=SimpleUploadedFile("proof.pdf", contents, content_type="application/pdf"))
        self.client.force_login(self.owner)
        response = self.client.get(reverse("attachment_download", args=[record.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(b"".join(response.streaming_content), contents)
        self.assertIn("attachment", response["Content-Disposition"])

    def test_citizen_cannot_approve_own_certificate(self):
        record = self.request_record(status=ServiceRequest.Status.UNDER_REVIEW)
        self.submit_transition(record, self.owner, status="approved", note="Forged approval")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.UNDER_REVIEW)
        self.assertIsNone(record.issued_at)
        self.assertFalse(record.updates.filter(to_status="approved").exists())

    def test_official_approval_issues_certificate_and_records_notification_and_audit(self):
        record = self.request_record(status=ServiceRequest.Status.UNDER_REVIEW)
        response = self.submit_transition(record, self.official, status="approved", note="Supporting records checked")
        self.assertIn(response.status_code, [200, 302])
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.APPROVED)
        self.assertIsNotNone(record.issued_at)
        update = StatusUpdate.objects.get(request=record, to_status="approved")
        self.assertEqual(update.actor, self.official)
        self.assertEqual(update.from_status, ServiceRequest.Status.UNDER_REVIEW)
        self.assertIn("Supporting records checked", update.note)
        self.assertTrue(Notification.objects.filter(user=self.owner, request=record, is_read=False).exists())

    def test_rejected_certificate_has_no_download(self):
        record = self.request_record(status=ServiceRequest.Status.REJECTED)
        self.client.force_login(self.owner)
        response = self.client.get(reverse("certificate_pdf", args=[record.pk]))
        self.assertIn(response.status_code, [403, 404])

    def test_other_citizen_cannot_download_approved_certificate(self):
        record = self.request_record(status=ServiceRequest.Status.APPROVED, issued_at=timezone.now())
        self.client.force_login(self.other)
        response = self.client.get(reverse("certificate_pdf", args=[record.pk]))
        self.assertIn(response.status_code, [403, 404])

    def test_public_verification_excludes_private_contact_and_request_details(self):
        record = self.request_record(status=ServiceRequest.Status.APPROVED, issued_at=timezone.now())
        response = self.client.get(reverse("verify", args=[record.verification_token]))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context["valid"])
        for private_value in (record.address, record.phone, self.owner.email, record.description):
            self.assertNotContains(response, private_value)

    def test_unapproved_certificate_is_not_publicly_valid(self):
        record = self.request_record()
        response = self.client.get(reverse("verify", args=[record.verification_token]))
        self.assertIn(response.status_code, [200, 404])
        self.assertFalse(response.context["valid"])

    def test_revocation_invalidates_token_and_download(self):
        record = self.request_record(status=ServiceRequest.Status.APPROVED, issued_at=timezone.now())
        self.submit_transition(record, self.official, status="revoked", note="Certificate issued against superseded records")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.REVOKED)
        self.client.logout()
        public_response = self.client.get(reverse("verify", args=[record.verification_token]))
        self.assertFalse(public_response.context["valid"])
        self.client.force_login(self.owner)
        self.assertIn(self.client.get(reverse("certificate_pdf", args=[record.pk])).status_code, [403, 404])

    def test_waste_schedule_requires_both_collector_and_date(self):
        incomplete_assignments = [
            {"scheduled_date": (timezone.localdate() + timedelta(days=2)).isoformat()},
            {"assigned_to": self.collector.pk},
        ]
        for incomplete in incomplete_assignments:
            with self.subTest(fields=incomplete):
                record = self.waste_record()
                self.submit_transition(record, self.official, status="scheduled", note="Incomplete schedule", **incomplete)
                record.refresh_from_db()
                self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)
                self.assertIsNone(record.scheduled_date)

    def test_waste_cannot_be_assigned_to_a_citizen(self):
        record = self.waste_record()
        self.submit_transition(record, self.official, status="scheduled", assigned_to=self.other.pk, scheduled_date=record.preferred_date.isoformat(), note="Invalid assignee")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)

    def test_official_can_schedule_waste_and_assigned_collector_can_complete_it(self):
        record = self.waste_record()
        self.submit_transition(record, self.official, status="scheduled", assigned_to=self.collector.pk, scheduled_date=record.preferred_date.isoformat(), note="Morning collection route")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.SCHEDULED)
        self.assertEqual(record.assigned_to, self.collector)
        self.assertEqual(record.scheduled_date, record.preferred_date)
        self.submit_transition(record, self.collector, status="collected", note="Collection completed")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.COLLECTED)
        self.assertTrue(record.updates.filter(actor=self.collector, to_status="collected").exists())

    def test_collector_cannot_read_or_complete_another_collectors_assignment(self):
        record = self.waste_record(status="scheduled", assigned_to=self.collector, scheduled_date=timezone.localdate())
        self.client.force_login(self.other_collector)
        self.assertIn(self.client.get(record.get_absolute_url()).status_code, [403, 404])
        self.client.post(record.get_absolute_url(), {"status": "collected", "note": "Not my assignment"})
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.SCHEDULED)

    def test_collector_cannot_read_unassigned_certificate(self):
        record = self.request_record()
        self.client.force_login(self.collector)
        self.assertIn(self.client.get(record.get_absolute_url()).status_code, [403, 404])

    def test_owner_can_cancel_an_early_request(self):
        record = self.request_record()
        self.submit_transition(record, self.owner, action="cancel", status="cancelled", note="No longer required")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.CANCELLED)
        self.assertTrue(record.updates.filter(actor=self.owner, to_status="cancelled").exists())

    def test_other_citizen_cannot_cancel_request(self):
        record = self.request_record()
        self.submit_transition(record, self.other, action="cancel", status="cancelled")
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)

    def test_notification_read_action_only_updates_current_users_notifications(self):
        owned = Notification.objects.create(user=self.owner, title="Your update", message="Your request changed")
        someone_elses = Notification.objects.create(user=self.other, title="Private update", message="Someone else's request changed")
        self.client.force_login(self.owner)
        response = self.client.post(reverse("notifications_read"), {})
        self.assertIn(response.status_code, [200, 204, 302])
        owned.refresh_from_db()
        someone_elses.refresh_from_db()
        self.assertTrue(owned.is_read)
        self.assertFalse(someone_elses.is_read)

    def test_notification_api_does_not_include_other_users_notifications(self):
        Notification.objects.create(user=self.owner, title="Visible owner update", message="For owner only")
        Notification.objects.create(user=self.other, title="Private other user marker 53b9", message="Confidential")
        self.client.force_login(self.owner)
        response = self.client.get(reverse("notifications_api"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["unread_count"], 1)
        self.assertNotContains(response, "Private other user marker 53b9")

    def test_citizen_cannot_export_all_service_records(self):
        self.client.force_login(self.owner)
        response = self.client.get(reverse("report_csv"))
        self.assertIn(response.status_code, [403, 404])

    def test_csv_export_escapes_spreadsheet_formula_prefixes(self):
        dangerous_title = '=HYPERLINK("https://example.invalid","Open")'
        self.request_record(title=dangerous_title)
        self.client.force_login(self.official)
        response = self.client.get(reverse("report_csv"))
        self.assertEqual(response.status_code, 200)
        body = b"".join(response.streaming_content) if response.streaming else response.content
        cells = [cell for row in csv.reader(io.StringIO(body.decode("utf-8-sig"))) for cell in row]
        self.assertNotIn(dangerous_title, cells)
        self.assertIn("'" + dangerous_title, cells)

    def test_waste_request_rejects_dates_outside_booking_window(self):
        data = {"category": "household", "address": "House 42, Village Road", "ward": 2,
                "phone": "9876543210", "preferred_date": timezone.localdate().isoformat()}
        self.assertTrue(RequestForm("waste", self.owner, data=data).is_valid())
        for days in (-1, 91):
            with self.subTest(days=days):
                data["preferred_date"] = (timezone.localdate() + timedelta(days=days)).isoformat()
                form = RequestForm("waste", self.owner, data=data)
                self.assertFalse(form.is_valid())
                self.assertIn("preferred_date", form.errors)

    def test_certificate_upload_rejects_disallowed_mismatched_and_oversize_files(self):
        data = {"applicant_name": "Test Resident", "certificate_type": "residence",
                "address": "House 42, Village Road", "ward": 2, "phone": "9876543210"}
        bad_uploads = [
            ("proof.html", b"<html>Not a document</html>"),
            ("proof.pdf", b"This is not PDF content"),
            ("proof.png", b"This is not PNG content"),
            ("proof.pdf", b"%PDF-" + b"0" * (5 * 1024 * 1024)),
        ]
        for filename, content in bad_uploads:
            with self.subTest(filename=filename, size=len(content)):
                upload = SimpleUploadedFile(filename, content, content_type="application/pdf")
                form = RequestForm("certificate", self.owner, data=data, files={"attachment": upload})
                self.assertFalse(form.is_valid())
                self.assertIn("attachment", form.errors)

    def test_registration_cannot_escalate_role_or_staff_permissions(self):
        response = self.client.post(reverse("register"), {
            "username": "new-resident", "first_name": "New", "last_name": "Resident",
            "email": "new-resident@example.com", "phone": "9876543210",
            "address": "House 42, Village Road", "ward": 2,
            "password1": "StrongResidentPassword!274", "password2": "StrongResidentPassword!274",
            "role": "collector", "is_staff": "true", "is_superuser": "true",
        })
        self.assertEqual(response.status_code, 302)
        registered = User.objects.get(username="new-resident")
        self.assertEqual(registered.profile.role, Profile.Role.CITIZEN)
        self.assertFalse(registered.is_staff)
        self.assertFalse(registered.is_superuser)

    def test_certificate_submission_approval_and_pdf_download(self):
        supporting_document = io.BytesIO()
        proof = canvas.Canvas(supporting_document)
        proof.drawString(50, 750, "Supporting document for automated workflow test")
        proof.save()
        self.client.force_login(self.owner)
        response = self.client.post(reverse("request_create", args=["certificate"]), {
            "applicant_name": "Test Resident", "certificate_type": "residence",
            "address": "House 42, Village Road", "ward": 2, "phone": "9876543210",
            "description": "Required for academic demonstration",
            "attachment": SimpleUploadedFile("proof.pdf", supporting_document.getvalue(), content_type="application/pdf"),
        })
        self.assertEqual(response.status_code, 302)
        record = ServiceRequest.objects.get(owner=self.owner, kind="certificate")
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)
        self.assertTrue(record.attachment)
        self.assertTrue(record.updates.filter(actor=self.owner, to_status="submitted").exists())
        self.assertTrue(Notification.objects.filter(user=self.owner, request=record).exists())
        self.assertEqual(self.submit_transition(record, self.official, status="approved", note="Supporting document verified").status_code, 302)
        self.client.force_login(self.owner)
        pdf_response = self.client.get(reverse("certificate_pdf", args=[record.pk]))
        self.assertEqual(pdf_response.status_code, 200)
        self.assertEqual(pdf_response["Content-Type"], "application/pdf")
        pdf_bytes = b"".join(pdf_response.streaming_content)
        self.assertTrue(pdf_bytes.startswith(b"%PDF-"))
        self.assertIn(b"%%EOF", pdf_bytes)

    def test_complaint_submission_and_resolution(self):
        self.client.force_login(self.owner)
        response = self.client.post(reverse("request_create", args=["complaint"]), {
            "title": "Street light near the community hall", "category": "roads",
            "description": "The street light has stopped working.",
            "address": "Community Hall Road", "ward": 2, "phone": "9876543210",
        })
        self.assertEqual(response.status_code, 302)
        record = ServiceRequest.objects.get(owner=self.owner, kind="complaint")
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)
        response = self.submit_transition(record, self.official, status="resolved", note="Street light repaired")
        self.assertEqual(response.status_code, 302)
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.RESOLVED)
        self.assertEqual(list(record.updates.values_list("to_status", flat=True)), ["submitted", "resolved"])
        self.assertFalse(record.can_download)

    def test_waste_submission_scheduling_and_collection(self):
        preferred_date = timezone.localdate() + timedelta(days=2)
        self.client.force_login(self.owner)
        response = self.client.post(reverse("request_create", args=["waste"]), {
            "category": "recyclable", "description": "Two bags of dry recyclable waste",
            "address": "House 42, Village Road", "ward": 2, "phone": "9876543210",
            "preferred_date": preferred_date.isoformat(),
        })
        self.assertEqual(response.status_code, 302)
        record = ServiceRequest.objects.get(owner=self.owner, kind="waste")
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)
        response = self.submit_transition(record, self.official, status="scheduled", assigned_to=self.collector.pk,
                                          scheduled_date=preferred_date.isoformat(), note="Collection confirmed")
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Notification.objects.filter(user=self.collector, request=record).exists())
        self.assertEqual(self.submit_transition(record, self.collector, status="collected", note="Waste collected").status_code, 302)
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.COLLECTED)
        self.assertEqual(list(record.updates.values_list("to_status", flat=True)), ["submitted", "scheduled", "collected"])

    def test_status_update_requires_csrf_token(self):
        record = self.request_record()
        protected_client = Client(enforce_csrf_checks=True)
        protected_client.force_login(self.official)
        response = protected_client.post(record.get_absolute_url(), {"status": "approved", "note": "Missing CSRF token"})
        self.assertEqual(response.status_code, 403)
        record.refresh_from_db()
        self.assertEqual(record.status, ServiceRequest.Status.SUBMITTED)

    def test_malformed_notification_id_returns_bad_request_without_marking_read(self):
        notification = Notification.objects.create(user=self.owner, title="Unread update", message="Still unread")
        self.client.force_login(self.owner)
        response = self.client.post(reverse("notifications_read"), {"notification_id": "not-an-integer"})
        self.assertEqual(response.status_code, 400)
        notification.refresh_from_db()
        self.assertFalse(notification.is_read)
