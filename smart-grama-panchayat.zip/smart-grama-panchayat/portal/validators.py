"""Validation shared by citizen forms and model fields."""

import re
import warnings
from pathlib import Path

from django.core.exceptions import ValidationError
from PIL import Image, UnidentifiedImageError


MAX_UPLOAD_BYTES = 5 * 1024 * 1024
ACCEPTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg"}


def validate_phone(value):
    if not value:
        return
    compact = re.sub(r"[\s()\-]", "", value)
    if not re.fullmatch(r"\+?\d{7,15}", compact):
        raise ValidationError("Enter a valid phone number with 7 to 15 digits.")


def validate_attachment(upload):
    """Accept small PDFs or verified PNG/JPEG images, irrespective of MIME claims."""
    if not upload:
        return
    if upload.size > MAX_UPLOAD_BYTES:
        raise ValidationError("Documents must be 5 MB or smaller.")
    extension = Path(upload.name).suffix.lower()
    if extension not in ACCEPTED_EXTENSIONS:
        raise ValidationError("Upload a PDF, PNG, or JPEG file.")
    try:
        upload.seek(0)
        if extension == ".pdf":
            if upload.read(5) != b"%PDF-":
                raise ValidationError("The uploaded file is not a valid PDF.")
        else:
            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                with Image.open(upload) as image:
                    expected = "PNG" if extension == ".png" else "JPEG"
                    if image.format != expected:
                        raise ValidationError("The image contents do not match its file extension.")
                    if image.width * image.height > 25_000_000:
                        raise ValidationError("Images must contain no more than 25 million pixels.")
                    image.verify()
    except ValidationError:
        raise
    except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombError,
            Image.DecompressionBombWarning) as exc:
        raise ValidationError("The image could not be verified. Upload a valid PNG or JPEG.") from exc
    finally:
        upload.seek(0)


def validate_poster(upload):
    if not upload:
        return
    if Path(upload.name).suffix.lower() not in {'.png', '.jpg', '.jpeg'}:
        raise ValidationError("Upload a PNG or JPEG poster image.")
    validate_attachment(upload)
