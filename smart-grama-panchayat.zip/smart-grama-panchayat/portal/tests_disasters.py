from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from .models import SafetyAlert, SafetyRecipient, Notification

class SafetyAlertTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin=User.objects.create_user('official',is_staff=True)
        cls.citizen=User.objects.create_user('citizen')
        cls.other=User.objects.create_user('other')
        cls.other.profile.ward=2;cls.other.profile.save()
        cls.inactive=User.objects.create_user('inactive',is_active=False)
    def data(self):
        return dict(title='Flood evacuation drill',action='evacuate',affected_area='River bank',ward=1,safe_place='Hill community hall',instructions='Use the designated north road.',contact='Panchayat control room')
    def issue(self):
        self.client.force_login(self.admin)
        response=self.client.post(reverse('safety_create'),self.data())
        self.assertEqual(response.status_code,302)
        return SafetyAlert.objects.latest('pk')
    def test_targeted_official_issue_and_notifications(self):
        alert=self.issue()
        self.assertEqual(list(alert.recipients.values_list('user_id',flat=True)),[self.citizen.pk])
        self.assertTrue(Notification.objects.filter(user=self.citizen,safety_alert=alert).exists())
        self.assertFalse(Notification.objects.filter(user=self.other).exists())
    def test_citizens_cannot_issue_or_close(self):
        alert=self.issue();self.client.force_login(self.citizen)
        self.assertEqual(self.client.post(reverse('safety_create'),self.data()).status_code,403)
        self.assertEqual(self.client.post(reverse('safety_close',args=[alert.pk]),{'closure_note':'done'}).status_code,403)
    def test_target_privacy_and_banner(self):
        alert=self.issue();self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse('safety_detail',args=[alert.pk])).status_code,404)
        self.assertNotContains(self.client.get(reverse('safety_banner')),alert.title)
        self.client.force_login(self.citizen)
        self.assertContains(self.client.get(reverse('dashboard')),'EVACUATE NOW')
        self.assertContains(self.client.get(reverse('safety_banner')),alert.safe_place)
    def test_acknowledgement_idempotent_and_warning_stays(self):
        alert=self.issue();self.client.force_login(self.citizen)
        url=reverse('safety_acknowledge',args=[alert.pk])
        self.client.post(url);first=SafetyRecipient.objects.get(alert=alert,user=self.citizen).acknowledged_at
        self.client.post(url)
        self.assertEqual(first,SafetyRecipient.objects.get(alert=alert,user=self.citizen).acknowledged_at)
        self.assertContains(self.client.get(reverse('safety_banner')),alert.title)
        self.client.force_login(self.other);self.assertEqual(self.client.post(url).status_code,404)
    def test_close_records_actor_and_notifies_removes_banner(self):
        alert=self.issue();url=reverse('safety_close',args=[alert.pk])
        self.client.post(url,{'closure_note':''});alert.refresh_from_db();self.assertIsNone(alert.closed_at)
        self.client.post(url,{'closure_note':'Drill complete; remain alert.'})
        alert.refresh_from_db();self.assertEqual(alert.closed_by,self.admin)
        self.assertEqual(Notification.objects.filter(safety_alert=alert).count(),2)
        self.client.post(url,{'closure_note':'Again'});self.assertEqual(Notification.objects.filter(safety_alert=alert).count(),2)
        self.client.force_login(self.citizen)
        self.assertNotContains(self.client.get(reverse('safety_banner')),alert.title)
        self.assertContains(self.client.get(reverse('safety_detail',args=[alert.pk])),'ALERT CLOSED')
    def test_all_wards_and_required_instructions(self):
        self.client.force_login(self.admin);data=self.data();data['safe_place']=''
        self.client.post(reverse('safety_create'),data);self.assertFalse(SafetyAlert.objects.exists())
        data=self.data();data['ward']='';self.client.post(reverse('safety_create'),data)
        self.assertEqual(SafetyRecipient.objects.count(),2)
    def test_old_report_entry_redirects_to_official_board(self):
        self.client.force_login(self.citizen)
        self.assertRedirects(self.client.post('/requests/new/disaster/',{}),reverse('disaster_alerts'))
        self.assertNotContains(self.client.get(reverse('disaster_alerts')),'Report a hazard')
    def test_official_tracking_and_notice_links(self):
        alert=self.issue()
        self.assertContains(self.client.get(reverse('safety_detail',args=[alert.pk])),'0 of 1')
        self.client.force_login(self.citizen)
        self.assertContains(self.client.get(reverse('notifications')),reverse('safety_detail',args=[alert.pk]))
