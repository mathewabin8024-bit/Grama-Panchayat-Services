import csv
import hashlib
import hmac
import io
import uuid
from functools import wraps
from pathlib import Path
from xml.sax.saxutils import escape

import qrcode
from django import forms
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.http import FileResponse, Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, Image, KeepTogether

from .certificates import ensure_issued_document, qr_bytes
from .forms import CertificateFileCheckForm, ProfileForm, RegistrationForm, RequestForm, TransitionForm
from .models import CertificateDocument, Announcement, Notification, Profile, ServiceRequest, StatusUpdate
from .services import allowed_transitions, create_request, is_collector, is_official, transition_request


def officials_only(view):
    @wraps(view)
    @login_required
    def wrapped(request, *args, **kwargs):
        if not is_official(request.user):
            raise PermissionDenied
        return view(request, *args, **kwargs)
    return wrapped


def visible_requests(user):
    qs = ServiceRequest.objects.select_related('owner', 'assigned_to')
    if is_official(user):
        return qs
    if is_collector(user):
        return qs.filter(kind='waste', assigned_to=user)
    return qs.filter(owner=user)


def get_item(user, pk):
    return get_object_or_404(visible_requests(user), pk=pk)


def home(request):
    return render(request, 'home.html', {'announcements': Announcement.objects.filter(is_published=True).order_by('-created_at')[:3]})


def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = RegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, 'Your account is ready. Welcome to Smart Grama.')
        return redirect('dashboard')
    return render(request, 'registration/register.html', {'form': form})


def summary(qs):
    total = qs.count()
    closed = qs.filter(status__in=['approved', 'resolved', 'collected']).count()
    active = qs.exclude(status__in=['approved', 'resolved', 'collected', 'rejected', 'cancelled', 'revoked']).count()
    stats = [
        {'label': 'Total requests', 'value': total, 'tone': 'blue'},
        {'label': 'In progress', 'value': active, 'tone': 'amber'},
        {'label': 'Completed', 'value': closed, 'tone': 'green'},
        {'label': 'Awaiting review', 'value': qs.filter(status='submitted').count(), 'tone': 'violet'},
    ]
    kind_counts = []
    for kind, label in ServiceRequest.Kind.choices:
        count = qs.filter(kind=kind).count()
        kind_counts.append({'label': label, 'count': count, 'percent': round(count / total * 100) if total else 0})
    return stats, kind_counts


@login_required
def dashboard(request):
    qs = visible_requests(request.user)
    stats, kind_counts = summary(qs)
    return render(request, 'portal/dashboard.html', {
        'stats': stats, 'kind_counts': kind_counts,
        'requests': qs.order_by('-updated_at')[:6],
        'announcements': Announcement.objects.filter(is_published=True).order_by('-created_at')[:3],
        'activity': StatusUpdate.objects.filter(request__in=qs).select_related('request', 'actor').order_by('-created_at')[:5],
    })


@login_required
def request_list(request):
    qs = visible_requests(request.user)
    kind = request.GET.get('kind', '')
    status = request.GET.get('status', '')
    q = request.GET.get('q', '').strip()[:150]
    if kind:
        qs = qs.filter(kind=kind)
    if status:
        qs = qs.filter(status=status)
    if q:
        qs = qs.filter(Q(reference__icontains=q) | Q(title__icontains=q) | Q(applicant_name__icontains=q))
    return render(request, 'portal/request_list.html', {
        'page_obj': Paginator(qs.order_by('-created_at'), 12).get_page(request.GET.get('page')),
        'kind': kind, 'status': status, 'q': q,
        'status_choices': ServiceRequest.Status.choices, 'kind_choices': ServiceRequest.Kind.choices,
    })


@login_required
def request_create(request, kind):
    if kind not in ServiceRequest.Kind.values:
        raise Http404
    if is_collector(request.user) or is_official(request.user):
        raise PermissionDenied
    if kind == 'disaster':
        return redirect('disaster_alerts')
    form = RequestForm(kind, request.user, request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        item = create_request(form, request.user)
        messages.success(request, f'Your request {item.reference} has been submitted.')
        return redirect('request_detail', pk=item.pk)
    labels = {'certificate': 'Apply for a certificate', 'complaint': 'Report a complaint', 'waste': 'Request waste collection', 'disaster': 'Report a weather hazard or disaster'}
    return render(request, 'portal/request_form.html', {'form': form, 'kind': kind, 'label': labels[kind]})


@login_required
def request_detail(request, pk):
    item = get_item(request.user, pk)
    can_manage = is_official(request.user) or (is_collector(request.user) and item.kind == 'waste' and item.assigned_to_id == request.user.pk)
    can_cancel = item.owner_id == request.user.pk and item.status in ['submitted', 'under_review']
    form = TransitionForm(item, actor=request.user) if can_manage and allowed_transitions(item, request.user) else None
    response_status = 200
    if request.method == 'POST':
        if request.POST.get('action') == 'cancel':
            if not can_cancel:
                raise PermissionDenied
            try:
                transition_request(item, request.user, {'status': 'cancelled', 'note': 'Cancelled by applicant.'})
                messages.success(request, 'Request cancelled.')
                return redirect('request_detail', pk=item.pk)
            except ValidationError as exc:
                messages.error(request, '; '.join(exc.messages))
                response_status = 400
        else:
            if not can_manage:
                raise PermissionDenied
            form = TransitionForm(item, request.POST, actor=request.user)
            if form.is_valid():
                try:
                    transition_request(item, request.user, form.cleaned_data)
                    messages.success(request, 'Status updated and the applicant has been notified.')
                    return redirect('request_detail', pk=item.pk)
                except ValidationError as exc:
                    form.add_error(None, exc)
            response_status = 400
    return render(request, 'portal/request_detail.html', {
        'item': item, 'updates': item.updates.select_related('actor').order_by('created_at'),
        'transition_form': form, 'can_manage': can_manage, 'can_cancel': can_cancel,
    }, status=response_status)


@login_required
def attachment_download(request, pk):
    item = get_item(request.user, pk)
    if not item.attachment:
        raise Http404
    try:
        with item.attachment.open('rb') as handle:
            data = handle.read()
    except FileNotFoundError:
        raise Http404
    response = FileResponse(io.BytesIO(data), as_attachment=True,
                            filename=f'{item.reference}-document{Path(item.attachment.name).suffix}', content_type='application/octet-stream')
    response['Cache-Control'] = 'private, no-store'
    return response


def certificate_for(user, pk):
    item = get_item(user, pk)
    if not item.can_download:
        raise Http404
    return item




@login_required
def certificate_qr(request, pk):
    item = certificate_for(request.user, pk)
    response = HttpResponse(qr_bytes(item).getvalue(), content_type='image/png')
    response['Cache-Control'] = 'private, no-store'
    return response


@login_required
def certificate_pdf(request, pk):
    item = certificate_for(request.user, pk)
    document = ensure_issued_document(item)
    response = FileResponse(io.BytesIO(bytes(document.pdf_bytes)), as_attachment=True,
                            filename=f'{item.reference}.pdf', content_type='application/pdf')
    response['Cache-Control'] = 'private, no-store'
    return response


def verify_lookup(request):
    error = ''
    token = request.GET.get('token', '').strip()
    if token:
        try:
            return redirect('verify', token=uuid.UUID(token.rstrip('/').split('/')[-1]))
        except (ValueError, AttributeError):
            error = 'Enter the verification code or the complete link from the certificate QR code.'
    return render(request, 'portal/verify_lookup.html', {'error': error, 'token': token})


def verify(request, token):
    record = ServiceRequest.objects.filter(verification_token=token, kind='certificate').first()
    valid = bool(record and record.can_download and record.issued_at)
    revoked = bool(record and record.status == 'revoked')
    document = CertificateDocument.objects.defer('pdf_bytes').filter(request=record).first() if valid else None
    safe_item = None
    verified_name = ''
    file_result = None
    form = CertificateFileCheckForm(request.POST or None, request.FILES or None) if document else None
    if valid:
        snapshot = document.snapshot if document else {}
        name = snapshot.get('subject_name') or snapshot.get('applicant_name') or record.applicant_name
        verified_name = ' '.join(word[0] + '.' for word in name.split() if word)
        safe_item = {'reference': snapshot.get('reference', record.reference),
                     'get_certificate_type_display': snapshot.get('type_label', record.get_certificate_type_display()),
                     'issued_at': record.issued_at}
        if request.method == 'POST' and form and form.is_valid():
            digest = hashlib.sha256()
            for chunk in form.cleaned_data['certificate_file'].chunks():
                digest.update(chunk)
            file_result = 'match' if hmac.compare_digest(digest.hexdigest(), document.sha256) else 'mismatch'
    response = render(request, 'portal/verify.html', {
        'item': safe_item, 'valid': valid, 'revoked': revoked, 'verified_name': verified_name,
        'file_form': form, 'file_result': file_result,
    })
    response['Cache-Control'] = 'no-store'
    response['X-Robots-Tag'] = 'noindex, nofollow'
    return response


@login_required
def notifications(request):
    return render(request, 'portal/notifications.html', {'page_obj': Paginator(request.user.notifications.order_by('-created_at'), 15).get_page(request.GET.get('page'))})


@login_required
def notifications_api(request):
    response = JsonResponse({'unread_count': request.user.notifications.filter(is_read=False).count()})
    response['Cache-Control'] = 'no-store'
    return response


@login_required
@require_POST
def notifications_read(request):
    notes = request.user.notifications.filter(is_read=False)
    if request.POST.get('notification_id'):
        try:
            notification_id = int(request.POST['notification_id'])
        except (ValueError, TypeError):
            return HttpResponse('Invalid notification identifier.', status=400)
        notes = notes.filter(pk=notification_id)
    notes.update(is_read=True)
    return redirect('notifications')


@login_required
def profile(request):
    profile_obj, _ = Profile.objects.get_or_create(user=request.user)
    form = ProfileForm(request.POST or None, instance=profile_obj)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Profile updated. Existing request details remain as submitted.')
        return redirect('profile')
    return render(request, 'portal/profile.html', {'form': form})


def announcements(request):
    qs = Announcement.objects.order_by('-created_at')
    if not is_official(request.user):
        qs = qs.filter(is_published=True)
    for notice in qs:
        notice.poster_available = bool(notice.poster and notice.poster.storage.exists(notice.poster.name))
    return render(request, 'portal/announcements.html', {'announcements': qs})


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ['title', 'category', 'body', 'event_date', 'venue', 'poster', 'is_published']
        widgets = {
            'body': forms.Textarea(attrs={'rows': 6}),
            'event_date': forms.DateInput(attrs={'type': 'date'}),
            'poster': forms.FileInput(attrs={'accept': '.png,.jpg,.jpeg,image/png,image/jpeg'}),
        }
        help_texts = {'poster': 'Optional PNG or JPEG poster, up to 5 MB. Add key information in the text too.',
                      'event_date': 'Optional date for a ceremony, meeting or community event.',
                      'is_published': 'Published notices and posters are visible to everyone.'}


@officials_only
def announcement_create(request):
    form = AnnouncementForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        item = form.save(commit=False)
        item.author = request.user
        item.save()
        messages.success(request, 'Announcement saved.')
        return redirect('announcements')
    return render(request, 'portal/announcement_form.html', {'form': form, 'title': 'Create an announcement'})


@officials_only
def announcement_edit(request, pk):
    item = get_object_or_404(Announcement, pk=pk)
    form = AnnouncementForm(request.POST or None, request.FILES or None, instance=item)
    if request.method == 'POST' and form.is_valid():
        item = form.save(commit=False)
        if request.POST.get('remove_poster') == '1' and not request.FILES.get('poster'):
            item.poster = ''
        item.save()
        messages.success(request, 'Notice updated.')
        return redirect('announcements')
    return render(request, 'portal/announcement_form.html', {'form': form, 'title': 'Edit notice', 'item': item})


def announcement_poster_view(request, pk):
    qs = Announcement.objects.all()
    if not is_official(request.user):
        qs = qs.filter(is_published=True)
    item = get_object_or_404(qs, pk=pk)
    available = bool(item.poster and item.poster.storage.exists(item.poster.name))
    response = render(request, 'portal/announcement_poster.html', {
        'announcement': item, 'poster_available': available,
    }, status=200 if available else 404)
    response['Cache-Control'] = 'no-store'
    return response


def announcement_poster(request, pk):
    qs = Announcement.objects.all()
    if not is_official(request.user):
        qs = qs.filter(is_published=True)
    item = get_object_or_404(qs, pk=pk)
    if not item.poster:
        raise Http404
    try:
        with item.poster.open('rb') as handle:
            data = handle.read()
    except FileNotFoundError:
        raise Http404
    mime = 'image/png' if Path(item.poster.name).suffix.lower() == '.png' else 'image/jpeg'
    response = FileResponse(io.BytesIO(data), content_type=mime)
    # Do not retain a published poster in browser caches after it is unpublished.
    response['Cache-Control'] = 'no-store'
    response['X-Content-Type-Options'] = 'nosniff'
    return response


@officials_only
@require_POST
def announcement_toggle(request, pk):
    item = get_object_or_404(Announcement, pk=pk)
    item.is_published = not item.is_published
    item.save(update_fields=['is_published'])
    return redirect('announcements')


@officials_only
def reports(request):
    qs = ServiceRequest.objects.all()
    stats, kind_counts = summary(qs)
    status_counts = [{'label': label, 'count': qs.filter(status=code).count()} for code, label in ServiceRequest.Status.choices]
    return render(request, 'portal/reports.html', {'stats': stats, 'kind_counts': kind_counts, 'status_counts': status_counts, 'recent_requests': qs.order_by('-created_at')[:10]})


def csv_safe(value):
    value = str(value or '')
    if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
        return "'" + value
    return value


@officials_only
def report_csv(request):
    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = 'attachment; filename="grama-service-report.csv"'
    response['Cache-Control'] = 'private, no-store'
    response.write('\ufeff')
    writer = csv.writer(response)
    writer.writerow(['Reference', 'Service', 'Title', 'Applicant', 'Status', 'Ward', 'Created', 'Scheduled', 'Assigned to'])
    for item in ServiceRequest.objects.select_related('assigned_to').order_by('-created_at').iterator():
        writer.writerow([csv_safe(v) for v in [item.reference, item.get_kind_display(), item.title, item.applicant_name, item.get_status_display(), item.ward, timezone.localtime(item.created_at).strftime('%Y-%m-%d %H:%M'), item.scheduled_date, item.assigned_to.get_full_name() or item.assigned_to.username if item.assigned_to else '']])
    return response


from django.db import transaction
from django.contrib.auth import get_user_model
from .models import SafetyAlert, SafetyRecipient
from .sms import queue_sms, configured, issue_body

class SafetyAlertForm(forms.ModelForm):
    class Meta:
        model = SafetyAlert
        fields = ['title', 'action', 'affected_area', 'ward', 'safe_place', 'instructions', 'sms_instructions', 'contact']
        labels = {'ward': 'Recipient ward (leave blank for all citizens)', 'safe_place': 'Safe relocation place / shelter', 'contact': 'Official contact / helpline', 'instructions': 'Relocation instructions and safe route', 'sms_instructions': 'Short SMS instructions (up to 350 characters)'}
        widgets = {'instructions': forms.Textarea(attrs={'rows': 5})}
        help_texts = {'ward': 'Sends to active citizen accounts whose registered ward matches. Blank sends to all active citizens.', 'safe_place': 'Specify the verified shelter name and exact location.', 'sms_instructions': 'Optional when the full instructions are 350 characters or fewer. Include the essential safe route/action. Area, shelter and contact are added automatically.', 'instructions': 'Tell citizens what action to take, how to reach the shelter, and where to get assistance.'}

    def clean(self):
        data = super().clean()
        if not data.get('sms_instructions') and len(data.get('instructions', '')) > 350:
            self.add_error('sms_instructions', 'Provide concise SMS instructions so the safety message is not truncated.')
        return data


def safety_visible(user):
    qs = SafetyAlert.objects.all()
    if not is_official(user):
        qs = qs.filter(recipients__user=user)
    return qs


@login_required
def disaster_alerts(request):
    qs = safety_visible(request.user)
    return render(request, 'portal/disaster_alerts.html', {'alerts': qs, 'official': is_official(request.user)})


@officials_only
def safety_create(request):
    form = SafetyAlertForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        with transaction.atomic():
            alert = form.save(commit=False)
            alert.issued_by = request.user
            alert.save()
            citizens = (get_user_model().objects
                .filter(is_active=True)
                .exclude(is_staff=True)
                .exclude(is_superuser=True)
                .filter(profile__role='citizen'))
            if alert.ward is not None:
                citizens = citizens.filter(profile__ward=alert.ward)
            recipients = list(citizens.order_by('pk').distinct())
            SafetyRecipient.objects.bulk_create([SafetyRecipient(alert=alert, user=u) for u in recipients])
            Notification.objects.bulk_create([Notification(user=u, safety_alert=alert,
                title=f'{alert.get_action_display()}: {alert.title}'[:180],
                message=f'Affected area: {alert.affected_area}. Safe place: {alert.safe_place}. Open the alert for instructions.') for u in recipients])
            queue_sms(alert)
        messages.success(request, f'Safety alert issued to {len(recipients)} citizen accounts. SMS outbox prepared; check delivery status below.')
        return redirect('safety_detail', pk=alert.pk)
    return render(request, 'portal/safety_form.html', {'form': form, 'sms_ready': configured(), 'sms_backend': settings.SMS_BACKEND})


@login_required
def safety_detail(request, pk):
    alert = get_object_or_404(safety_visible(request.user), pk=pk)
    recipient = SafetyRecipient.objects.filter(alert=alert, user=request.user).first()
    return render(request, 'portal/safety_detail.html', {'alert': alert, 'recipient': recipient,
        'official': is_official(request.user), 'recipient_count': alert.recipients.count(),
        'sms_ready': configured(), 'sms_backend': settings.SMS_BACKEND,
        'sms_preview': issue_body(alert),
        'sms_rows': alert.sms_deliveries.select_related('user').order_by('created_at') if is_official(request.user) else [],
        'ack_count': alert.recipients.filter(acknowledged_at__isnull=False).count()})


@login_required
@require_POST
def safety_acknowledge(request, pk):
    recipient = get_object_or_404(SafetyRecipient, alert_id=pk, user=request.user)
    SafetyRecipient.objects.filter(pk=recipient.pk, acknowledged_at__isnull=True).update(acknowledged_at=timezone.now())
    return redirect('safety_detail', pk=pk)


@officials_only
@require_POST
def safety_close(request, pk):
    with transaction.atomic():
        alert = get_object_or_404(SafetyAlert.objects.select_for_update(), pk=pk)
        note = request.POST.get('closure_note', '').strip()
        if not note or len(note) > 1000:
            messages.error(request, 'Give a closure explanation of up to 1,000 characters.')
            return redirect('safety_detail', pk=pk)
        if not alert.closed_at:
            alert.closed_at = timezone.now(); alert.closed_by = request.user; alert.closure_note = note
            alert.save(update_fields=['closed_at', 'closed_by', 'closure_note'])
            Notification.objects.bulk_create([Notification(user_id=r.user_id, safety_alert=alert,
                title=f'Safety alert closed: {alert.title}'[:180], message=note) for r in alert.recipients.all()])
    return redirect('safety_detail', pk=pk)


@login_required
def safety_banner(request):
    return render(request, 'includes/safety_banner.html')
