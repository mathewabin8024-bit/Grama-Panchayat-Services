from django.db import migrations, models


def repair_legacy_backend(apps, schema_editor):
    SafetySMS = apps.get_model('portal', 'SafetySMS')
    SafetySMS.objects.filter(models.Q(backend__isnull=True) | models.Q(backend='')).update(backend='twilio')


class Migration(migrations.Migration):
    dependencies = [
        ('portal', '0007_safetysms_backend'),
    ]

    operations = [
        migrations.RunPython(repair_legacy_backend, migrations.RunPython.noop),
    ]
