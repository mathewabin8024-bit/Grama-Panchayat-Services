from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import ServiceRequest

class PortalLanguageTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username='language-user', password='Password123!')
        self.client.force_login(self.user)

    def switch(self, language='ml', target='/dashboard/'):
        return self.client.post('/language/', {'language':language, 'next':target})

    def test_preference_persists_and_switches_back(self):
        self.switch()
        self.user.profile.refresh_from_db()
        self.assertEqual(self.user.profile.language, 'ml')
        self.assertContains(self.client.get('/dashboard/'), 'എന്റെ അപേക്ഷകൾ')
        self.client.logout()
        self.client.force_login(self.user)
        self.assertContains(self.client.get('/dashboard/'), 'lang="ml"')
        self.switch('en')
        self.assertContains(self.client.get('/dashboard/'), 'My requests')

    def test_collector_can_switch_but_official_cannot(self):
        self.user.profile.role='collector'
        self.user.profile.save()
        self.switch()
        self.assertContains(self.client.get('/dashboard/'), 'നിങ്ങളുടെ ശേഖരണ വിവരങ്ങൾ')
        self.user.is_staff=True
        self.user.save()
        self.assertEqual(self.switch().status_code,403)
        self.assertContains(self.client.get('/dashboard/'), 'lang="en"')
        self.assertNotContains(self.client.get('/dashboard/'), 'class="language-switch"')

    def test_safe_redirect_and_invalid_preference(self):
        self.assertRedirects(self.switch(target='https://example.com/'), '/dashboard/')
        self.assertEqual(self.switch('invalid').status_code,400)
        self.assertEqual(self.client.get('/language/').status_code,405)
        client=Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        self.assertEqual(client.post('/language/', {'language':'ml'}).status_code,403)

    def test_forms_and_stored_content(self):
        self.switch()
        item=ServiceRequest.objects.create(owner=self.user,kind='complaint',title='Overview',description='My requests',address='Main road',ward=1,phone='9876543210')
        response=self.client.get(item.get_absolute_url())
        self.assertContains(response,'Overview')
        self.assertContains(response,'Main road')
        response=self.client.get('/requests/new/certificate/')
        self.assertContains(response,'ജനന സർട്ടിഫിക്കറ്റ്')
        self.assertContains(response,'value="birth"')
        self.assertContains(response,'അപേക്ഷകന്റെ പേര്')
        response=self.client.post('/requests/new/certificate/',{'certificate_type':'birth'})
        self.assertTrue(response.context['form'].errors)
        self.assertNotContains(response, 'This field is required.')

    def test_citizen_pages_render_in_malayalam(self):
        self.switch()
        for path in ['/dashboard/','/requests/','/profile/','/notifications/','/announcements/','/disaster-alerts/','/verify/','/requests/new/waste/','/requests/new/complaint/']:
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code,200)

