from django.conf import settings
from django.utils import timezone
from .models import SafetyAlert
from .services import is_collector, is_official

def portal_context(request):
    return {
        'is_official': is_official(request.user),
        'is_collector': is_collector(request.user),
        'unread_count': request.user.notifications.filter(is_read=False).count() if request.user.is_authenticated else 0,
        'active_safety_alerts': SafetyAlert.objects.filter(recipients__user=request.user, closed_at__isnull=True) if request.user.is_authenticated else SafetyAlert.objects.none(),
        'today': timezone.localdate(),
        'demo_mode': settings.DEMO_MODE,
    }
