"""Read-only record inspection; workflow decisions happen in the portal."""

from django.contrib import admin

from .models import CertificateDocument, Announcement, Notification, Profile, ServiceRequest, StatusUpdate


class ReadOnlyAdmin(admin.ModelAdmin):
    def get_readonly_fields(self, request, obj=None):
        return tuple(field.name for field in self.model._meta.fields)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    actions = None


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ["user", "role", "ward", "phone"]
    list_filter = ["role", "ward"]
    search_fields = ["user__username", "user__first_name", "user__last_name", "phone"]

    def get_readonly_fields(self, request, obj=None):
        return ("user",) if request.user.is_superuser else ("user", "role")

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(ServiceRequest)
class ServiceRequestAdmin(ReadOnlyAdmin):
    list_display = ["reference", "kind", "owner", "status", "ward", "created_at"]
    list_filter = ["kind", "status", "ward"]
    search_fields = ["reference", "title", "owner__username"]
    list_select_related = ["owner"]


@admin.register(StatusUpdate)
class StatusUpdateAdmin(ReadOnlyAdmin):
    list_display = ["request", "actor", "from_status", "to_status", "created_at"]
    list_select_related = ["request", "actor"]


@admin.register(Notification)
class NotificationAdmin(ReadOnlyAdmin):
    list_display = ["title", "user", "is_read", "created_at"]
    list_select_related = ["user"]


@admin.register(Announcement)
class AnnouncementAdmin(ReadOnlyAdmin):
    list_display = ["title", "is_published", "author", "created_at"]


@admin.register(CertificateDocument)
class CertificateDocumentAdmin(ReadOnlyAdmin):
    list_display = ['request', 'sha256', 'created_at']
    fields = ['request', 'sha256', 'snapshot', 'created_at']
    def get_readonly_fields(self, request, obj=None):
        return self.fields
