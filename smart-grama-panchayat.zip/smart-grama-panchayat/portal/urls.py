from django.contrib.auth import views as auth_views
from django.urls import path
from . import views

from .language import set_language

urlpatterns = [
    path('language/', set_language, name='portal_language'),
    path('', views.home, name='home'),
    path('accounts/login/', auth_views.LoginView.as_view(redirect_authenticated_user=True), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('accounts/register/', views.register, name='register'),
    path('safety-alerts/new/', views.safety_create, name='safety_create'),
    path('safety-alerts/banner/', views.safety_banner, name='safety_banner'),
    path('safety-alerts/<int:pk>/', views.safety_detail, name='safety_detail'),
    path('safety-alerts/<int:pk>/acknowledge/', views.safety_acknowledge, name='safety_acknowledge'),
    path('safety-alerts/<int:pk>/close/', views.safety_close, name='safety_close'),
    path('disaster-alerts/', views.disaster_alerts, name='disaster_alerts'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('requests/', views.request_list, name='request_list'),
    path('requests/new/<str:kind>/', views.request_create, name='request_create'),
    path('requests/<int:pk>/', views.request_detail, name='request_detail'),
    path('requests/<int:pk>/attachment/', views.attachment_download, name='attachment_download'),
    path('requests/<int:pk>/certificate.pdf', views.certificate_pdf, name='certificate_pdf'),
    path('requests/<int:pk>/qr.png', views.certificate_qr, name='certificate_qr'),
    path('notifications/', views.notifications, name='notifications'),
    path('notifications/count/', views.notifications_api, name='notifications_api'),
    path('notifications/read/', views.notifications_read, name='notifications_read'),
    path('profile/', views.profile, name='profile'),
    path('verify/', views.verify_lookup, name='verify_lookup'),
    path('verify/<uuid:token>/', views.verify, name='verify'),
    path('announcements/', views.announcements, name='announcements'),
    path('announcements/new/', views.announcement_create, name='announcement_create'),
    path('announcements/<int:pk>/edit/', views.announcement_edit, name='announcement_edit'),
    path('announcements/<int:pk>/poster/', views.announcement_poster, name='announcement_poster'),
    path('announcements/<int:pk>/view-poster/', views.announcement_poster_view, name='announcement_poster_view'),
    path('announcements/<int:pk>/toggle/', views.announcement_toggle, name='announcement_toggle'),
    path('reports/', views.reports, name='reports'),
    path('reports/export.csv', views.report_csv, name='report_csv'),
]
