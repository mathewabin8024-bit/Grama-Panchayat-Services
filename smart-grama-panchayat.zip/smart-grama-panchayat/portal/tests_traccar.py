from unittest.mock import patch, MagicMock
from django.test import TestCase, override_settings
from django.contrib.auth.models import User
from .models import SafetyAlert,SafetyRecipient,SafetySMS
from .sms import configured,queue_sms,process_outbox,traccar_request

@override_settings(SMS_BACKEND='traccar',TRACCAR_SMS_URL='http://192.168.1.5:8082',TRACCAR_SMS_KEY='private-test-key')
class TraccarTests(TestCase):
 def setUp(self):
  user=User.objects.create_user('resident');user.profile.phone='+919876543210';user.profile.save()
  admin=User.objects.create_user('official',is_staff=True)
  self.alert=SafetyAlert.objects.create(title='Drill',action='prepare',affected_area='River',safe_place='Hall',instructions='Test only',contact='Office',issued_by=admin)
  SafetyRecipient.objects.create(user=user,alert=self.alert)
 def test_configuration(self):
  self.assertTrue(configured())
  with override_settings(TRACCAR_SMS_URL='http://example.com:8082'):self.assertFalse(configured())
  with override_settings(TRACCAR_SMS_KEY=''):self.assertFalse(configured())
 @patch('portal.sms.traccar_request')
 @patch('portal.sms.provider_request')
 def test_phone_submission_no_false_delivery_or_twilio_calls(self,twilio,phone):
  queue_sms(self.alert);process_outbox();process_outbox()
  row=SafetySMS.objects.get();self.assertEqual(row.backend,'traccar');self.assertEqual(row.status,'submitted')
  phone.assert_called_once();twilio.assert_not_called()
 @patch('portal.sms.traccar_request',side_effect=TimeoutError)
 def test_uncertain_send_not_duplicated(self,phone):
  queue_sms(self.alert);process_outbox();process_outbox()
  self.assertEqual(SafetySMS.objects.get().status,'unknown');phone.assert_called_once()
 @patch('portal.sms.traccar_request')
 def test_old_provider_queue_not_sent(self,phone):
  with override_settings(SMS_BACKEND='twilio'):queue_sms(self.alert)
  process_outbox();phone.assert_not_called()
 @patch('portal.sms.request.build_opener')
 def test_local_payload_and_auth_header(self,build):
  import json
  response=MagicMock();response.status=200;build.return_value.open.return_value.__enter__.return_value=response
  traccar_request('+919876543210','DEMO TEST')
  req=build.return_value.open.call_args.args[0]
  self.assertEqual(req.get_header('Authorization'),'private-test-key')
  self.assertEqual(json.loads(req.data),{'to':'+919876543210','message':'DEMO TEST'})

 @patch('portal.sms.traccar_request')
 def test_requeue_preserves_sent_snapshot(self,phone):
  queue_sms(self.alert);process_outbox()
  row=SafetySMS.objects.get();original_body=row.body
  self.alert.instructions='Changed instructions';self.alert.save()
  queue_sms(self.alert);process_outbox();row.refresh_from_db()
  self.assertEqual(row.status,'submitted');self.assertEqual(row.body,original_body)
  phone.assert_called_once()
