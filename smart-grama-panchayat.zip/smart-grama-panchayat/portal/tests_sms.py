from datetime import timedelta
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from django.test import TestCase, override_settings
from django.contrib.auth.models import User
from django.utils import timezone
from .models import SafetyAlert, SafetyRecipient, SafetySMS
from .sms import queue_sms, process_outbox, normalize_phone
from .views import SafetyAlertForm

@override_settings(SMS_BACKEND='twilio', TWILIO_ACCOUNT_SID='AC'+'a'*32, TWILIO_AUTH_TOKEN='test-token', TWILIO_FROM_NUMBER='+15005550006', TWILIO_MESSAGING_SERVICE_SID='', SMS_DEFAULT_COUNTRY_CODE='91')
class SafetySMSTests(TestCase):
    def setUp(self):
        self.admin=User.objects.create_user('admin',is_staff=True)
        self.citizen=User.objects.create_user('citizen')
        self.citizen.profile.phone='9876543210';self.citizen.profile.save()
        self.alert=SafetyAlert.objects.create(title='Test flood',action='evacuate',affected_area='River bank',safe_place='Hill hall',instructions='Use north road.',contact='Control room',issued_by=self.admin)
        SafetyRecipient.objects.create(alert=self.alert,user=self.citizen)
    def queued(self):
        queue_sms(self.alert);return SafetySMS.objects.get()
    def test_number_normalization(self):
        self.assertEqual(normalize_phone('98765 43210'),'+919876543210')
        self.assertEqual(normalize_phone('+44 7700 900123'),'+447700900123')
        self.assertEqual(normalize_phone('bad number'),'')
    def test_durable_unique_body(self):
        sms=self.queued();queue_sms(self.alert)
        self.assertEqual(SafetySMS.objects.count(),1)
        for text in ['EVACUATE NOW','River bank','Hill hall','Use north road']:
            self.assertIn(text,sms.body)
        self.assertNotIn('http',sms.body)
        self.assertNotIn('DEMO DRILL',sms.body)
    @override_settings(SMS_BACKEND='disabled')
    @patch('portal.sms.provider_request')
    def test_disabled_never_sends(self,send):
        sms=self.queued();process_outbox();send.assert_not_called()
        sms.refresh_from_db();self.assertEqual(sms.status,'pending')
    @override_settings(SMS_BACKEND='simulation')
    @patch('portal.sms.provider_request')
    def test_simulation_honest(self,send):
        sms=self.queued();process_outbox();send.assert_not_called()
        sms.refresh_from_db();self.assertEqual(sms.status,'simulated')
    @patch('portal.sms.provider_request')
    def test_submitted_then_delivered_not_resent(self,send):
        sms=self.queued();send.side_effect=[{'sid':'SM'+'b'*32},{'status':'sent'},{'status':'delivered'}]
        process_outbox();sms.refresh_from_db();self.assertEqual(sms.status,'submitted')
        process_outbox();sms.refresh_from_db();self.assertEqual(sms.status,'delivered')
        self.assertEqual(send.call_count,3)
        self.assertEqual(send.call_args_list[0].args[0]['To'],'+919876543210')
    @patch('portal.sms.provider_request',side_effect=URLError('timeout'))
    def test_uncertain_submission_not_retried(self,send):
        sms=self.queued();process_outbox();process_outbox()
        sms.refresh_from_db();self.assertEqual(sms.status,'unknown');self.assertEqual(send.call_count,1)
    @patch('portal.sms.provider_request',side_effect=HTTPError('https://example.invalid',429,'rate limit',{},None))
    def test_rate_limit_retries_are_delayed_and_bounded(self,send):
        sms=self.queued();process_outbox();process_outbox()
        sms.refresh_from_db();self.assertEqual(sms.status,'pending');self.assertEqual(send.call_count,1)
        for _ in range(2):
            SafetySMS.objects.update(next_attempt=timezone.now()-timedelta(seconds=1));process_outbox()
        sms.refresh_from_db();self.assertEqual(sms.status,'failed');self.assertEqual(sms.attempts,3)
    @patch('portal.sms.provider_request')
    def test_invalid_missing_expired_closed_do_not_send(self,send):
        self.citizen.profile.phone='';self.citizen.profile.save();sms=self.queued()
        self.assertEqual(sms.status,'invalid_number');process_outbox();send.assert_not_called()
        SafetySMS.objects.update(status='pending',expires_at=timezone.now()-timedelta(seconds=1))
        process_outbox();sms.refresh_from_db();self.assertEqual(sms.status,'expired')
        SafetySMS.objects.update(status='pending',expires_at=timezone.now()+timedelta(minutes=5))
        self.alert.closed_at=timezone.now();self.alert.save()
        process_outbox();sms.refresh_from_db();self.assertEqual(sms.status,'cancelled');send.assert_not_called()
    def test_long_instructions_require_explicit_sms_summary(self):
        data=dict(title='Flood',action='evacuate',affected_area='River',safe_place='Hill hall',instructions='x'*351,contact='Control room')
        form=SafetyAlertForm(data);self.assertFalse(form.is_valid());self.assertIn('sms_instructions',form.errors)
        data['sms_instructions']='Use north road.';self.assertTrue(SafetyAlertForm(data).is_valid())
    def test_issue_web_flow_queues_and_reports_status(self):
        self.client.force_login(self.admin)
        data=dict(title='Drill',action='prepare',affected_area='River',safe_place='Hill hall',instructions='Prepare',contact='Office')
        response=self.client.post('/safety-alerts/new/',data)
        self.assertEqual(response.status_code,302)
        self.assertEqual(SafetySMS.objects.count(),1)
        self.assertContains(self.client.get(response.url),'pending')
    def test_closure_does_not_queue_sms(self):
        self.queued()
        self.client.force_login(self.admin)
        response=self.client.post(f'/safety-alerts/{self.alert.pk}/close/',{'closure_note':'Drill complete'})
        self.assertEqual(response.status_code,302)
        self.alert.refresh_from_db();self.assertIsNotNone(self.alert.closed_at)
        queue_sms(self.alert,'closure')
        self.assertEqual(SafetySMS.objects.count(),1)
        self.assertFalse(SafetySMS.objects.filter(event='closure').exists())
        from .models import Notification
        self.assertTrue(Notification.objects.filter(user=self.citizen,safety_alert=self.alert,title__startswith='Safety alert closed:').exists())

    @patch('portal.sms.provider_request')
    def test_preexisting_closure_sms_cancelled(self,send):
        sms=self.queued();sms.event='closure';sms.save()
        process_outbox();sms.refresh_from_db()
        self.assertEqual(sms.status,'cancelled');send.assert_not_called()

    def test_sms_format_and_short_instructions(self):
        from .sms import issue_body
        self.alert.sms_instructions='Use the marked route.'
        body=issue_body(self.alert)
        self.assertEqual(body.splitlines(),[
            'Emergency alert: Extreme','[Sending date and time IST]','',
            'Test flood','Area: River bank','Action: EVACUATE NOW',
            'Safe place: Hill hall','Instructions: Use the marked route.',
            'Helpline: Control room','— Panchayat'])
        self.assertNotIn('Use north road.',body)

    @patch('portal.sms.provider_request')
    def test_timestamp_is_submission_time_in_ist(self,send):
        from datetime import datetime, timezone as dt_timezone
        sms=self.queued()
        submitted_at=timezone.now()+timedelta(minutes=2)
        send.side_effect=[{'sid':'SM'+'c'*32},{'status':'sent'}]
        with patch('portal.sms.timezone.now',return_value=submitted_at):
            process_outbox()
        from zoneinfo import ZoneInfo
        expected=submitted_at.astimezone(ZoneInfo('Asia/Kolkata')).strftime('%d %b %Y, %I:%M %p IST')
        sms.refresh_from_db()
        self.assertEqual(sms.body.splitlines()[1],expected)
        self.assertEqual(send.call_args_list[0].args[0]['Body'],sms.body)
