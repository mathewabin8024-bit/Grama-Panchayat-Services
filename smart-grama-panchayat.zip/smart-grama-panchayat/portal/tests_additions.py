"""Birth/death certificates, issued PDF integrity, and digital notice board regression tests."""
import hashlib
import io
import os
import tempfile
import uuid
from datetime import timedelta
from pathlib import Path

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from .forms import RequestForm
from .models import Announcement, CertificateDocument, ServiceRequest
from .services import create_request, transition_request


class CertificateAndNoticeTests(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.temp_media = tempfile.TemporaryDirectory(prefix='grama-additions-')
        cls.media_setting = override_settings(MEDIA_ROOT=cls.temp_media.name)
        cls.media_setting.enable()

    @classmethod
    def tearDownClass(cls):
        for model in [Announcement, ServiceRequest]:
            for obj in model.objects.all():
                for field_name in ['poster', 'attachment']:
                    field = getattr(obj, field_name, None)
                    if field and hasattr(field, 'close'):
                        try:
                            field.close()
                        except Exception:
                            pass
        cls.media_setting.disable()
        try:
            cls.temp_media.cleanup()
        except PermissionError:
            for root, _, files in os.walk(cls.temp_media.name, topdown=False):
                for name in files:
                    try:
                        os.unlink(os.path.join(root, name))
                    except OSError:
                        pass
            try:
                os.rmdir(cls.temp_media.name)
            except OSError:
                pass
        super().tearDownClass()

    @classmethod
    def setUpTestData(cls):
        cls.citizen = User.objects.create_user('resident', password='Example!123')
        cls.official = User.objects.create_user('clerk', password='Example!123', is_staff=True)

    def image(self, name='poster.png', color='blue'):
        buffer = io.BytesIO()
        Image.new('RGB', (60, 80), color).save(buffer, format='PNG')
        return SimpleUploadedFile(name, buffer.getvalue(), content_type='image/png')

    def certificate_data(self, kind='birth'):
        return dict(certificate_type=kind, applicant_name='Demo Applicant',
                    subject_name='Demo Child' if kind == 'birth' else 'Demo Person',
                    event_date=(timezone.localdate()-timedelta(days=20)).isoformat(),
                    event_place='Sample Hospital', applicant_relationship='Parent' if kind == 'birth' else 'Child',
                    parent_one='Demo Parent', parent_two='Second Demo Parent',
                    address='Private Sample Address', ward=3, phone='9999999999')

    def issued(self, kind='birth'):
        form = RequestForm('certificate', self.citizen, data=self.certificate_data(kind), files={'attachment': self.image()})
        self.assertTrue(form.is_valid(), form.errors)
        item = create_request(form, self.citizen)
        return transition_request(item, self.official, {'status':'approved','note':'Reviewed sample evidence.'})

    def test_event_registration_fields_and_death_parents_saved(self):
        data=self.certificate_data('death')
        data.update(sex='female',registration_number='REG-42',registration_date=timezone.localdate().isoformat())
        form=RequestForm('certificate',self.citizen,data=data,files={'attachment':self.image()})
        self.assertTrue(form.is_valid(),form.errors)
        item=create_request(form,self.citizen)
        self.assertEqual(item.registration_number,'REG-42')
        self.assertEqual(item.sex,'female')
        self.assertEqual(item.parent_two,'Second Demo Parent')

    def test_registration_cannot_precede_event(self):
        data=self.certificate_data()
        data.update(event_date='2025-01-02',registration_date='2025-01-01')
        form=RequestForm('certificate',self.citizen,data=data,files={'attachment':self.image()})
        self.assertFalse(form.is_valid())
        self.assertIn('registration_date',form.errors)

    def test_birth_application_requires_event_and_parent_details(self):
        data=self.certificate_data()
        for field in ['subject_name','event_date','event_place','applicant_relationship','parent_one']:
            with self.subTest(field=field):
                incomplete={**data,field:''}
                form=RequestForm('certificate',self.citizen,data=incomplete,files={'attachment':self.image()})
                self.assertFalse(form.is_valid())
                self.assertIn(field,form.errors)

    def test_death_application_does_not_require_or_save_parent_details(self):
        data=self.certificate_data('death')
        data.pop('parent_one');data.pop('parent_two')
        form=RequestForm('certificate',self.citizen,data=data,files={'attachment':self.image()})
        self.assertTrue(form.is_valid(),form.errors)
        item=create_request(form,self.citizen)
        self.assertEqual(item.certificate_type,'death')
        self.assertEqual(item.subject_name,'Demo Person')
        self.assertEqual(item.parent_one,'')

    def test_future_birth_or_death_date_is_rejected(self):
        for kind in ['birth','death']:
            data=self.certificate_data(kind)
            data['event_date']=(timezone.localdate()+timedelta(days=1)).isoformat()
            form=RequestForm('certificate',self.citizen,data=data,files={'attachment':self.image()})
            self.assertFalse(form.is_valid())
            self.assertIn('event_date',form.errors)

    def test_non_event_certificate_clears_unrelated_fields(self):
        form=RequestForm('certificate',self.citizen,data=self.certificate_data('residence'),files={'attachment':self.image()})
        self.assertTrue(form.is_valid(),form.errors)
        item=create_request(form,self.citizen)
        self.assertEqual(item.subject_name,'')
        self.assertIsNone(item.event_date)
        self.assertEqual(item.parent_one,'')

    def test_incomplete_birth_record_cannot_be_approved_by_bypassing_form(self):
        item=ServiceRequest.objects.create(owner=self.citizen,kind='certificate',certificate_type='birth',title='Birth',address='Sample',phone='9999999999')
        with self.assertRaises(ValidationError):
            transition_request(item,self.official,{'status':'approved'})
        item.refresh_from_db()
        self.assertEqual(item.status,'submitted')
        self.assertFalse(CertificateDocument.objects.filter(request=item).exists())

    def test_approval_freezes_pdf_with_integrity_hash(self):
        item=self.issued()
        original=item.issued_document
        self.assertTrue(bytes(original.pdf_bytes).startswith(b'%PDF-'))
        self.assertEqual(original.sha256,hashlib.sha256(bytes(original.pdf_bytes)).hexdigest())
        self.assertEqual(original.snapshot['subject_name'],'Demo Child')
        self.assertEqual(original.snapshot['certificate_type'],'birth')

    def test_repeated_downloads_are_identical_despite_source_field_changes(self):
        item=self.issued('death')
        expected=bytes(item.issued_document.pdf_bytes)
        self.client.force_login(self.citizen)
        url=reverse('certificate_pdf',args=[item.pk])
        for _ in range(2):
            response=self.client.get(url)
            self.assertEqual(b''.join(response.streaming_content),expected)
            response.close()
        ServiceRequest.objects.filter(pk=item.pk).update(subject_name='Changed name')
        response=self.client.get(url)
        self.assertEqual(b''.join(response.streaming_content),expected)
        response.close()

    def test_original_pdf_passes_public_check_without_saving_uploaded_file(self):
        item=self.issued()
        before=set(Path(self.temp_media.name).rglob('*'))
        response=self.client.post(reverse('verify',args=[item.verification_token]),{
            'certificate_file':SimpleUploadedFile('certificate.pdf',bytes(item.issued_document.pdf_bytes),content_type='application/pdf')})
        self.assertEqual(response.context['file_result'],'match')
        self.assertContains(response,'Original PDF confirmed')
        self.assertEqual(before,set(Path(self.temp_media.name).rglob('*')))
        for private in ['Private Sample Address','Demo Parent','Sample Hospital','9999999999','Demo Child']:
            self.assertNotContains(response,private)

    def test_changed_pdf_with_valid_qr_fails(self):
        item=self.issued()
        altered=bytes(item.issued_document.pdf_bytes)+b'\n% changed document\n'
        response=self.client.post(reverse('verify',args=[item.verification_token]),{
            'certificate_file':SimpleUploadedFile('changed.pdf',altered,content_type='application/pdf')})
        self.assertTrue(response.context['valid'])
        self.assertEqual(response.context['file_result'],'mismatch')
        self.assertContains(response,'PDF does not match the issued original')

    def test_different_certificate_cannot_use_another_valid_qr(self):
        first,second=self.issued('birth'),self.issued('death')
        response=self.client.post(reverse('verify',args=[first.verification_token]),{
            'certificate_file':SimpleUploadedFile('other.pdf',bytes(second.issued_document.pdf_bytes),content_type='application/pdf')})
        self.assertEqual(response.context['file_result'],'mismatch')

    def test_revoked_certificate_never_passes_even_with_original_file(self):
        item=self.issued()
        content=bytes(item.issued_document.pdf_bytes)
        transition_request(item,self.official,{'status':'revoked','note':'Withdrawn after review.'})
        response=self.client.post(reverse('verify',args=[item.verification_token]),{
            'certificate_file':SimpleUploadedFile('original.pdf',content,content_type='application/pdf')})
        self.assertFalse(response.context['valid'])
        self.assertIsNone(response.context['file_result'])
        self.assertContains(response,'Certificate revoked')

    def test_unknown_code_does_not_show_upload_or_claim_validity(self):
        response=self.client.get(reverse('verify',args=[uuid.uuid4()]))
        self.assertFalse(response.context['valid'])
        self.assertIsNone(response.context['file_form'])

    def test_pdf_check_rejects_wrong_type_and_oversized_upload(self):
        item=self.issued()
        for filename,content in [('x.png',b'%PDF-1.4'),('x.pdf',b'not a PDF'),('x.pdf',b'%PDF-'+b'x'*(5*1024*1024))]:
            response=self.client.post(reverse('verify',args=[item.verification_token]),{'certificate_file':SimpleUploadedFile(filename,content)})
            self.assertIn('certificate_file',response.context['file_form'].errors)
            self.assertIsNone(response.context['file_result'])

    def test_official_can_publish_ceremony_with_poster_and_event_details(self):
        self.client.force_login(self.official)
        response=self.client.post(reverse('announcement_create'),dict(title='Sample opening ceremony',category='ceremony',body='Please join the sample event.',event_date=timezone.localdate().isoformat(),venue='Sample hall',poster=self.image(),is_published='on'))
        self.assertEqual(response.status_code,302)
        notice=Announcement.objects.get(title='Sample opening ceremony')
        self.assertEqual(notice.category,'ceremony');self.assertTrue(notice.poster)
        self.client.logout()
        board=self.client.get(reverse('announcements'))
        self.assertContains(board,'Sample opening ceremony');self.assertContains(board,'Sample hall')
        poster=self.client.get(reverse('announcement_poster',args=[notice.pk]))
        self.assertEqual(poster.status_code,200);self.assertEqual(poster['Content-Type'],'image/png')
        self.assertTrue(b''.join(poster.streaming_content).startswith(b'\x89PNG'));poster.close()

    def test_unpublished_notice_and_poster_are_private(self):
        notice=Announcement.objects.create(title='Private draft marker',body='Draft',poster=self.image(),is_published=False,author=self.official)
        self.assertNotContains(self.client.get(reverse('announcements')),'Private draft marker')
        self.assertEqual(self.client.get(reverse('announcement_poster',args=[notice.pk])).status_code,404)
        self.client.force_login(self.citizen)
        self.assertEqual(self.client.get(reverse('announcement_poster',args=[notice.pk])).status_code,404)
        self.client.force_login(self.official)
        response=self.client.get(reverse('announcement_poster',args=[notice.pk]))
        self.assertEqual(response.status_code,200);response.close()

    def test_unpublishing_hides_previously_public_poster(self):
        notice=Announcement.objects.create(title='Sample notice',body='Text',poster=self.image(),author=self.official)
        self.client.force_login(self.official)
        self.client.post(reverse('announcement_toggle',args=[notice.pk]))
        self.client.logout()
        self.assertEqual(self.client.get(reverse('announcement_poster',args=[notice.pk])).status_code,404)

    def test_citizens_cannot_create_or_edit_notices(self):
        notice=Announcement.objects.create(title='Original title',body='Details',author=self.official)
        self.client.force_login(self.citizen)
        self.assertEqual(self.client.post(reverse('announcement_create'),{'title':'Forbidden','body':'Text'}).status_code,403)
        self.assertEqual(self.client.post(reverse('announcement_edit',args=[notice.pk]),{'title':'Changed','body':'Text'}).status_code,403)
        notice.refresh_from_db();self.assertEqual(notice.title,'Original title')

    def test_official_can_edit_notice_and_remove_poster(self):
        notice=Announcement.objects.create(title='Old title',body='Old text',poster=self.image(),author=self.official)
        self.client.force_login(self.official)
        response=self.client.post(reverse('announcement_edit',args=[notice.pk]),dict(title='Updated title',body='New text',category='meeting',venue='Hall',remove_poster='1',is_published='on'))
        self.assertEqual(response.status_code,302)
        notice.refresh_from_db();self.assertEqual(notice.title,'Updated title');self.assertFalse(notice.poster)
        self.assertEqual(self.client.get(reverse('announcement_poster',args=[notice.pk])).status_code,404)

    def test_full_poster_opens_in_same_tab_and_displays_image(self):
        notice = Announcement.objects.create(title='Poster preview', body='Details',
                                             poster=self.image(), author=self.official)
        self.client.force_login(self.official)
        board = self.client.get(reverse('announcements'))
        preview_url = reverse('announcement_poster_view', args=[notice.pk])
        self.assertContains(board, f'href="{preview_url}"')
        self.assertNotContains(board, 'target="_blank"')
        response = self.client.get(preview_url)
        self.assertContains(response, f'src="{reverse("announcement_poster", args=[notice.pk])}"')
        self.assertContains(response, f'#announcement-{notice.pk}')
        self.assertEqual(response['Cache-Control'], 'no-store')

    def test_full_poster_draft_access_remains_private(self):
        notice = Announcement.objects.create(title='Private poster', body='Draft',
                                             poster=self.image(), is_published=False, author=self.official)
        url = reverse('announcement_poster_view', args=[notice.pk])
        self.assertEqual(self.client.get(url).status_code, 404)
        self.client.force_login(self.citizen)
        self.assertEqual(self.client.get(url).status_code, 404)
        self.client.force_login(self.official)
        self.assertEqual(self.client.get(url).status_code, 200)

    def test_missing_poster_has_explanation_and_admin_replacement_link(self):
        notice = Announcement.objects.create(title='Missing poster', body='Keep these details',
                                             poster='notices/missing.jpg', author=self.official)
        self.client.force_login(self.official)
        board = self.client.get(reverse('announcements'))
        self.assertContains(board, 'Poster unavailable')
        self.assertContains(board, 'Keep these details')
        self.assertNotContains(board, f'src="{reverse("announcement_poster", args=[notice.pk])}"')
        response = self.client.get(reverse('announcement_poster_view', args=[notice.pk]))
        self.assertContains(response, 'Upload a replacement poster', status_code=404)
        self.client.logout()
        response = self.client.get(reverse('announcement_poster_view', args=[notice.pk]))
        self.assertContains(response, 'Poster unavailable', status_code=404)
        self.assertNotContains(response, 'Upload a replacement poster', status_code=404)

    def test_notice_rejects_invalid_image(self):
        self.client.force_login(self.official)
        for filename,content in [('poster.svg',b'<svg></svg>'),('poster.png',b'not an image')]:
            response=self.client.post(reverse('announcement_create'),dict(title='Bad poster',category='general',body='Text',poster=SimpleUploadedFile(filename,content)))
            self.assertEqual(response.status_code,200)
            self.assertIn('poster',response.context['form'].errors)
        self.assertFalse(Announcement.objects.filter(title='Bad poster').exists())
