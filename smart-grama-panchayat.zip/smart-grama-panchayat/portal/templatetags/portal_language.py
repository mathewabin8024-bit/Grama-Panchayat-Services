from copy import deepcopy
from django import template
from django import forms
from portal.language import ui

register = template.Library()
register.filter('ui', ui)

@register.filter
def localized_fields(form):
    """Translate display metadata, retaining field values and validation behavior."""
    for original in form:
        field = deepcopy(original.field)
        field.label = ui(original.label)
        field.help_text = ui(field.help_text)
        if isinstance(field, forms.ChoiceField) and not isinstance(field, forms.ModelChoiceField):
            field.choices = [(value, ui(label)) for value, label in field.choices]
        for key in ('placeholder', 'aria-label', 'title'):
            if key in field.widget.attrs:
                field.widget.attrs[key] = ui(field.widget.attrs[key])
        yield field.get_bound_field(form, original.name)
