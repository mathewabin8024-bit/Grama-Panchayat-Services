"""Generate and retain the original PDF and its SHA-256 fingerprint at issuance."""
import io
from pathlib import Path
import hashlib
from xml.sax.saxutils import escape
import qrcode
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.urls import reverse
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, Image, KeepTogether
from .models import CertificateDocument, ServiceRequest


def qr_bytes(item):
    buffer = io.BytesIO()
    qrcode.make(settings.PUBLIC_BASE_URL + reverse('verify', args=[item.verification_token])).save(buffer, format='PNG')
    buffer.seek(0)
    return buffer


def render_certificate_pdf(item):
    """Reference-inspired event certificate; never invent registry data or authority."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=46, rightMargin=46,
        topMargin=112, bottomMargin=48, title=f'{item.reference} - {item.get_certificate_type_display()}',
        author='Smart Digital Grama Panchayat Services')
    body = ParagraphStyle('eventBody', fontName='Times-Roman', fontSize=10.5, leading=14)
    bold = ParagraphStyle('eventBold', parent=body, fontName='Times-Bold')
    center = ParagraphStyle('eventCenter', parent=body, alignment=1)
    heading = ParagraphStyle('eventHeading', parent=center, fontName='Times-Bold',fontSize=19,leading=24)
    small = ParagraphStyle('eventSmall', parent=body, fontSize=9,leading=12)
    def para(value, style=body):
        return Paragraph(escape(str(value or 'Not recorded')).replace('\n','<br/>'),style)
    date = lambda value: value.strftime('%d-%b-%Y').upper() if value else 'Not recorded'
    issued = date(timezone.localtime(item.issued_at)) if item.issued_at else 'Not issued'
    title = item.get_certificate_type_display().upper()
    if item.certificate_type in ('birth', 'death'):
        event = 'Birth' if item.certificate_type == 'birth' else 'Death'
        statement = (f'This is to certify that the following information relating to the {event.lower()} '
            'has been recorded in the approved application maintained by the Smart Digital Grama Panchayat Services project. '
            'This document represents the project record and is not an extract from a statutory civil register.')
        rows = [('Name of child' if event=='Birth' else 'Name of deceased',item.subject_name),
            ('Sex', item.get_sex_display()), (f'Date of {event.lower()}',date(item.event_date)),(f'Place of {event.lower()}',item.event_place)]
        rows += [('Father / guardian' if event=='Birth' else 'Father / husband / guardian',item.parent_one),
            ('Mother / second parent / guardian',item.parent_two),
            ('Registration No.',item.registration_number),('Date of registration',date(item.registration_date))]
        rows += [('Applicant name',item.applicant_name),('Relationship to person',item.applicant_relationship),
            ('Address supplied in application',item.address),('Ward',item.ward)]
    else:
        statements = {
            'residence': 'This is to certify that the residence application of the person named below has been approved in the Smart Digital Grama Panchayat Services project. The residential address and ward recorded in the application are set out below.',
            'ownership': 'This is to certify that the property ownership application submitted by the person named below has been approved in the Smart Digital Grama Panchayat Services project. The details below reflect the approved application and do not establish legal title to property.',
            'general': 'This is to certify that the application of the person named below has been approved in the Smart Digital Grama Panchayat Services project for the purpose recorded below.',
        }
        statement = statements.get(item.certificate_type, statements['general'])
        rows = [('Applicant name',item.applicant_name),
            ('Residential address' if item.certificate_type=='residence' else 'Applicant address',item.address),
            ('Ward',item.ward),('Purpose / details recorded',item.description)]
    table = Table([[para(label),para(': '+str(value or 'Not recorded'),bold)] for label,value in rows],colWidths=[185,306])
    table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),
        ('RIGHTPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
    story=[Spacer(1,2),
        Paragraph(f'<u>{escape(title)}</u>',heading),Spacer(1,6),
        Paragraph('ACADEMIC PROJECT - NOT AN OFFICIAL CERTIFICATE',ParagraphStyle('disclaimer',parent=center,fontSize=8,leading=11)),
        Spacer(1,14),para(statement),
        Spacer(1,16),table,Spacer(1,16)]
    signature_path = Path(__file__).resolve().parent / 'assets' / 'head-officer-signature.png'
    signature_image = Image(str(signature_path), width=128, height=70, kind='proportional')
    signature_image.hAlign = 'CENTER'
    signature_art = Table([[signature_image]], colWidths=[233])
    signature_art.setStyle(TableStyle([('ALIGN',(0,0),(-1,-1),'CENTER'),('TOPPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),0)]))
    signature=[Paragraph('Certified by',center),signature_art,
        Paragraph('ABIN MATHEW',ParagraphStyle('signer',parent=center,fontName='Times-Bold')),
        Paragraph('Head Officer',center)]
    details=[para('Certificate No: '+item.reference,bold),Spacer(1,5),para('Date of issue: '+issued,bold)]
    signing=Table([[details,signature]],colWidths=[246,245]);signing.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0)]))
    url=settings.PUBLIC_BASE_URL+reverse('verify',args=[item.verification_token])
    verification=Table([[Image(qr_bytes(item),width=82,height=82),Paragraph(
        '<b>Certificate verification</b><br/>Scan the QR code to check the current status. Upload the downloaded PDF on '
        'the verification page to confirm it matches the issued original. A signature image is not a cryptographic digital signature.',small)]],colWidths=[100,391])
    verification.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),0)]))
    story += [KeepTogether([signing,Spacer(1,14),verification,Spacer(1,8),
        para('Verification code: '+str(item.verification_token),small),
        Paragraph(f'<link href="{escape(url)}">Open certificate verification</link>',small)])]
    def footer(page,document):
        # Website brand lockup in the upper-left corner.
        page.saveState()
        page.translate(46,A4[1]-88)
        page.scale(0.625,0.625)
        page.setFillColor(colors.HexColor('#225ce4'))
        page.roundRect(0,0,64,64,15,stroke=0,fill=1)
        page.setStrokeColor(colors.white);page.setLineWidth(4)
        page.setLineCap(1);page.setLineJoin(1)
        mark=page.beginPath()
        mark.moveTo(12,36);mark.lineTo(32,52);mark.lineTo(52,36)
        mark.moveTo(17,39);mark.lineTo(17,13);mark.lineTo(47,13);mark.lineTo(47,39)
        mark.moveTo(27,13);mark.lineTo(27,30);mark.lineTo(37,30);mark.lineTo(37,13)
        page.drawPath(mark);page.restoreState()
        page.saveState()
        page.setFont('Helvetica-Bold',17)
        page.setFillColor(colors.HexColor('#132c4d'))
        page.drawString(96,A4[1]-63,'Smart')
        page.setFillColor(colors.HexColor('#225ce4'))
        page.drawString(145,A4[1]-63,'Grama')
        page.setFont('Helvetica-Bold',6)
        page.setFillColor(colors.HexColor('#5f6e80'))
        page.drawString(96,A4[1]-78,'S M A R T  P A N C H A Y A T  S E R V I C E S')
        page.restoreState()
        page.saveState();page.setFont('Times-Roman',8)
        page.drawString(46,28,'Academic project record. No government authority is implied.')
        page.drawRightString(A4[0]-46,28,f'Page {document.page}');page.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return buffer.getvalue()


@transaction.atomic
def ensure_issued_document(item):
    """Also supports old approved records that predate frozen PDF storage."""
    record = ServiceRequest.objects.select_for_update().get(pk=item.pk)
    if not record.can_download or not record.issued_at:
        raise ValidationError("Only an approved, issued certificate can have an original PDF.")
    existing = CertificateDocument.objects.filter(request=record).first()
    if existing:
        return existing
    snapshot = {name: getattr(record, name) for name in [
        'reference', 'certificate_type', 'applicant_name', 'subject_name', 'event_place',
        'applicant_relationship', 'parent_one', 'parent_two', 'address', 'ward', 'description', 'sex', 'registration_number',
    ]}
    snapshot['type_label'] = record.get_certificate_type_display()
    snapshot['registration_date'] = record.registration_date.isoformat() if record.registration_date else None
    snapshot['event_date'] = record.event_date.isoformat() if record.event_date else None
    snapshot['issued_at'] = record.issued_at.isoformat()
    pdf = render_certificate_pdf(record)
    return CertificateDocument.objects.create(request=record, snapshot=snapshot, pdf_bytes=pdf, sha256=hashlib.sha256(pdf).hexdigest())
