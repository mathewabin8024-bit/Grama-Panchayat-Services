"""Citizen service records and their immutable activity history."""

import uuid
from pathlib import Path

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.urls import reverse
from django.utils import timezone

from .validators import validate_attachment, validate_phone, validate_poster


def request_reference():
    return "GP-" + uuid.uuid4().hex[:12].upper()


def private_attachment_path(instance, filename):
    return f"requests/{uuid.uuid4().hex}{Path(filename).suffix.lower()}"


class Profile(models.Model):
    class Role(models.TextChoices):
        CITIZEN = "citizen", "Citizen"
        COLLECTOR = "collector", "Waste collector"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    language = models.CharField(max_length=2, choices=[("en", "English"), ("ml", "Malayalam")], default="en")
    phone = models.CharField(max_length=25, blank=True, validators=[validate_phone])
    address = models.TextField(blank=True, max_length=1000)
    ward = models.PositiveSmallIntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(100)])
    role = models.CharField(max_length=12, choices=Role.choices, default=Role.CITIZEN)

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} â€” {self.get_role_display()}"


@receiver(post_save, sender=settings.AUTH_USER_MODEL, dispatch_uid="portal.ensure_user_profile")
def ensure_user_profile(sender, instance, created, raw=False, **kwargs):
    if created and not raw:
        Profile.objects.get_or_create(user=instance)


class ServiceRequest(models.Model):
    class Kind(models.TextChoices):
        CERTIFICATE = "certificate", "Certificate"
        COMPLAINT = "complaint", "Complaint"
        WASTE = "waste", "Waste collection"
        DISASTER = "disaster", "Weather & disaster alert"

    class Status(models.TextChoices):
        SUBMITTED = "submitted", "Submitted"
        UNDER_REVIEW = "under_review", "Under review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        IN_PROGRESS = "in_progress", "In progress"
        RESOLVED = "resolved", "Resolved"
        SCHEDULED = "scheduled", "Scheduled"
        COLLECTED = "collected", "Collected"
        CANCELLED = "cancelled", "Cancelled"
        REVOKED = "revoked", "Revoked"

    class CertificateType(models.TextChoices):
        BIRTH = "birth", "Birth certificate"
        DEATH = "death", "Death certificate"
        RESIDENCE = "residence", "Residence certificate"
        OWNERSHIP = "ownership", "Property ownership certificate"
        GENERAL = "general", "General certificate"

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="service_requests")
    reference = models.CharField(max_length=20, unique=True, default=request_reference, editable=False)
    kind = models.CharField(max_length=16, choices=Kind.choices)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True, max_length=5000)
    applicant_name = models.CharField(max_length=150, blank=True)
    certificate_type = models.CharField(max_length=20, choices=CertificateType.choices, blank=True)
    subject_name = models.CharField("Person named on certificate", max_length=150, blank=True)
    event_date = models.DateField("Date of birth / death", null=True, blank=True)
    sex = models.CharField(max_length=20, blank=True, choices=[('male','Male'),('female','Female'),('other','Other')])
    registration_number = models.CharField('Birth / death registration number', max_length=80, blank=True)
    registration_date = models.DateField('Date of birth / death registration', null=True, blank=True)
    event_place = models.CharField("Place of birth / death", max_length=200, blank=True)
    applicant_relationship = models.CharField("Relationship to the person", max_length=80, blank=True)
    parent_one = models.CharField("Parent / guardian name", max_length=150, blank=True)
    parent_two = models.CharField("Second parent / guardian name", max_length=150, blank=True)
    severity = models.CharField(max_length=10, blank=True, choices=[("low", "Low"), ("moderate", "Moderate"), ("high", "High"), ("critical", "Critical")])
    category = models.CharField(max_length=80, blank=True)
    address = models.TextField(max_length=1000)
    ward = models.PositiveSmallIntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(100)])
    phone = models.CharField(max_length=25, validators=[validate_phone])
    preferred_date = models.DateField(null=True, blank=True)
    scheduled_date = models.DateField(null=True, blank=True)
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, related_name="assigned_requests", null=True, blank=True)
    attachment = models.FileField(upload_to=private_attachment_path, validators=[validate_attachment], blank=True)
    verification_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    issued_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at", "-pk"]
        indexes = [models.Index(fields=["kind", "status"]), models.Index(fields=["owner", "-created_at"])]

    def __str__(self):
        return f"{self.reference} â€” {self.title}"

    def get_absolute_url(self):
        return reverse("request_detail", kwargs={"pk": self.pk})

    @property
    def is_certificate(self):
        return self.kind == self.Kind.CERTIFICATE

    @property
    def can_download(self):
        return self.is_certificate and self.status == self.Status.APPROVED

    @property
    def is_closed(self):
        return self.status in {self.Status.APPROVED, self.Status.REJECTED, self.Status.RESOLVED,
                               self.Status.COLLECTED, self.Status.CANCELLED, self.Status.REVOKED}


class StatusUpdate(models.Model):
    request = models.ForeignKey(ServiceRequest, on_delete=models.CASCADE, related_name="updates")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    from_status = models.CharField(max_length=20, choices=ServiceRequest.Status.choices, blank=True)
    to_status = models.CharField(max_length=20, choices=ServiceRequest.Status.choices)
    note = models.TextField(blank=True, max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at", "pk"]

    def __str__(self):
        return f"{self.request.reference}: {self.get_to_status_display()}"


class Notification(models.Model):
    safety_alert = models.ForeignKey("SafetyAlert", on_delete=models.SET_NULL, null=True, blank=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    request = models.ForeignKey(ServiceRequest, on_delete=models.SET_NULL, related_name="notifications", null=True, blank=True)
    title = models.CharField(max_length=180)
    message = models.TextField(max_length=2000)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-pk"]

    def __str__(self):
        return self.title


def notice_poster_path(instance, filename):
    return f"notices/{uuid.uuid4().hex}{Path(filename).suffix.lower()}"


class Announcement(models.Model):
    class Category(models.TextChoices):
        GENERAL = "general", "General notice"
        CEREMONY = "ceremony", "Ceremony"
        MEETING = "meeting", "Meeting"
        EVENT = "event", "Community event"

    category = models.CharField(max_length=20, choices=Category.choices, default=Category.GENERAL)
    event_date = models.DateField(null=True, blank=True)
    venue = models.CharField(max_length=200, blank=True)
    poster = models.ImageField(upload_to=notice_poster_path, validators=[validate_poster], blank=True)
    title = models.CharField(max_length=180)
    body = models.TextField(max_length=5000)
    is_published = models.BooleanField(default=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-pk"]

    def __str__(self):
        return self.title


class CertificateDocument(models.Model):
    """One frozen issued PDF; retained after revocation, never regenerated on download."""
    request = models.OneToOneField(ServiceRequest, on_delete=models.PROTECT, related_name="issued_document")
    pdf_bytes = models.BinaryField(editable=False)
    sha256 = models.CharField(max_length=64, editable=False)
    snapshot = models.JSONField(editable=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Issued certificate {self.request.reference}"


class SafetyAlert(models.Model):
    sms_instructions = models.CharField(max_length=350, blank=True)
    title = models.CharField(max_length=180)
    action = models.CharField(max_length=12, choices=[('evacuate', 'EVACUATE NOW'), ('prepare', 'PREPARE TO RELOCATE')])
    affected_area = models.CharField(max_length=300)
    ward = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(100)])
    safe_place = models.CharField(max_length=300)
    instructions = models.TextField(max_length=5000)
    contact = models.CharField(max_length=150)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    closed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='closed_safety_alerts')
    closure_note = models.TextField(max_length=2000, blank=True)
    class Meta:
        ordering = ['-created_at', '-pk']

class SafetyRecipient(models.Model):
    alert = models.ForeignKey(SafetyAlert, on_delete=models.CASCADE, related_name='recipients')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['alert', 'user'], name='unique_safety_recipient')]


class SafetySMS(models.Model):
    backend = models.CharField(max_length=20, default="twilio")
    alert = models.ForeignKey(SafetyAlert, on_delete=models.CASCADE, related_name='sms_deliveries')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    event = models.CharField(max_length=10, default='issue')
    phone = models.CharField(max_length=20, blank=True)
    body = models.TextField(max_length=1600)
    status = models.CharField(max_length=20, default='pending')
    provider_id = models.CharField(max_length=40, blank=True)
    attempts = models.PositiveSmallIntegerField(default=0)
    error = models.CharField(max_length=240, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    next_attempt = models.DateTimeField(default=timezone.now)
    expires_at = models.DateTimeField()
    class Meta:
        constraints = [models.UniqueConstraint(fields=['alert', 'user', 'event'], name='unique_alert_sms_event')]
