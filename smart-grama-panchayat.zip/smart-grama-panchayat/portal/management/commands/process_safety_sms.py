import time
from django.core.management.base import BaseCommand
from portal.sms import process_outbox, configured
from django.conf import settings

class Command(BaseCommand):
    help = 'Process safety SMS outbox and poll delivery receipts; --watch repeats every 15 seconds.'
    def add_arguments(self, parser):
        parser.add_argument('--watch', action='store_true')
    def handle(self, *args, **options):
        self.stdout.write('SMS mode: '+settings.SMS_BACKEND)
        if not configured() and settings.SMS_BACKEND != 'simulation':
            self.stdout.write('Real sending is disabled or incomplete; messages remain pending until expiry.')
        try:
            while True:
                count = process_outbox()
                if count: self.stdout.write(f'Processed {count} outbox records. See the alert page for delivery states.')
                if not options['watch']: break
                time.sleep(15)
        except KeyboardInterrupt:
            self.stdout.write('SMS worker stopped.')
