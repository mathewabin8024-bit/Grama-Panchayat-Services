from django.core.management.base import BaseCommand
from portal.models import ServiceRequest
from portal.certificates import ensure_issued_document

class Command(BaseCommand):
    help = 'Store original PDFs for previously approved certificates without replacing existing originals.'

    def handle(self, *args, **options):
        pending = ServiceRequest.objects.filter(kind='certificate', status='approved', issued_at__isnull=False, issued_document__isnull=True)
        count = 0
        for item in pending.iterator():
            ensure_issued_document(item)
            count += 1
        self.stdout.write(self.style.SUCCESS(f'Prepared {count} original certificate PDFs. Existing originals were preserved.'))
