"""Create a clearly marked, repeatable local demonstration dataset."""

import io
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from PIL import Image, ImageDraw

from portal.models import Announcement, Notification, Profile, ServiceRequest, StatusUpdate
from portal.services import transition_request


DEMO_PASSWORD = "Demo@Grama2026!"
ACCOUNTS = {
    "admin": {"first_name": "Demo", "last_name": "Administrator", "email": "admin@demo.grama.local", "is_staff": True, "is_superuser": True, "role": "citizen"},
    "citizen": {"first_name": "Anu", "last_name": "Thomas", "email": "citizen@demo.grama.local", "is_staff": False, "is_superuser": False, "role": "citizen"},
    "collector": {"first_name": "Ravi", "last_name": "Kumar", "email": "collector@demo.grama.local", "is_staff": False, "is_superuser": False, "role": "collector"},
}
RECORDS = [
    ("GP-DEMO000001", "certificate", "Residence certificate", "residence", "approved"),
    ("GP-DEMO000002", "certificate", "Property ownership certificate", "ownership", "under_review"),
    ("GP-DEMO000003", "certificate", "General certificate", "general", "submitted"),
    ("GP-DEMO000004", "complaint", "Streetlight near the sample community hall", "roads", "in_progress"),
    ("GP-DEMO000005", "complaint", "Drain cleaning on the sample ward road", "sanitation", "resolved"),
    ("GP-DEMO000006", "complaint", "Water supply enquiry for the sample neighbourhood", "water", "submitted"),
    ("GP-DEMO000007", "waste", "Household waste collection", "household", "submitted"),
    ("GP-DEMO000008", "waste", "Dry and recyclable waste collection", "recyclable", "scheduled"),
    ("GP-DEMO000009", "waste", "Garden waste collection", "garden", "collected"),
]
NOTICES = [
    ("Welcome to the Smart Grama demonstration", "This academic project contains sample accounts and fictional service requests. Try submitting a certificate application, reporting a civic issue, or requesting waste collection. This demonstration is not a live government service."),
    ("How certificate verification works", "An approved sample certificate includes a QR code. Its verification page checks the current application status and displays limited information. All generated certificates are marked as academic demonstrations and have no official validity."),
]


class Command(BaseCommand):
    help = "Seed local academic demo accounts and requests without changing existing accounts."

    def handle(self, *args, **options):
        if not settings.DEBUG or not getattr(settings, "DEMO_MODE", False):
            raise CommandError("Demo data can only be created when DEBUG and DEMO_MODE are both enabled.")
        created_files = []
        try:
            with transaction.atomic():
                if self.existing_demo_is_complete():
                    self.stdout.write(self.style.SUCCESS("Demo data already exists. Existing passwords and request states were left unchanged."))
                    return
                accounts = self.create_accounts()
                self.create_requests(accounts, created_files)
                for title, body in NOTICES:
                    Announcement.objects.create(title=title, body=body, author=accounts["admin"], is_published=True)
        except Exception:
            # File storage is not transactional; remove only files this run created.
            for storage, name in created_files:
                storage.delete(name)
            raise
        self.stdout.write(self.style.SUCCESS("Created 3 demo accounts, 9 service requests, and 2 sample announcements."))
        self.stdout.write("New account usernames: admin / citizen / collector")
        self.stdout.write(f"Password for these NEW local demo accounts: {DEMO_PASSWORD}")
        self.stdout.write("Existing account passwords are never reset by this command.")

    def existing_demo_is_complete(self):
        User = get_user_model()
        users = {user.username: user for user in User.objects.filter(username__in=ACCOUNTS).select_related("profile")}
        references = [row[0] for row in RECORDS]
        existing_records = {item.reference: item for item in ServiceRequest.objects.filter(reference__in=references)}
        if not users and not existing_records:
            return False
        error = "The demo usernames or references already exist with conflicting or incomplete data. No accounts were changed. Use a fresh local demo database or choose different non-demo usernames."
        if len(users) != len(ACCOUNTS) or len(existing_records) != len(RECORDS):
            raise CommandError(error)
        for username, expected in ACCOUNTS.items():
            user = users[username]
            if not user.is_active:
                raise CommandError(error)
            for field in ["first_name", "last_name", "email", "is_staff", "is_superuser"]:
                if getattr(user, field) != expected[field]:
                    raise CommandError(error)
            try:
                role = user.profile.role
            except Profile.DoesNotExist:
                raise CommandError(error)
            if role != expected["role"]:
                raise CommandError(error)
        for reference, kind, title, category, status in RECORDS:
            record = existing_records[reference]
            if record.owner_id != users["citizen"].pk or record.kind != kind or record.title != title:
                raise CommandError(error)
        # Statuses may legitimately change while the user explores the demo.
        return True

    def create_accounts(self):
        User = get_user_model()
        accounts = {}
        for username, sample in ACCOUNTS.items():
            user_fields = {key: value for key, value in sample.items() if key != "role"}
            user = User.objects.create_user(username=username, password=DEMO_PASSWORD, **user_fields)
            profile, _ = Profile.objects.get_or_create(user=user)
            profile.role = sample["role"]
            profile.phone = "9999999999"
            profile.address = "Sample House 5, Demonstration Road\nSample Ward, Kerala (fictional demo address)"
            profile.ward = 5
            profile.full_clean()
            profile.save()
            # The creation signal may have cached the initial blank profile.
            user.profile = profile
            accounts[username] = user
        return accounts

    @staticmethod
    def sample_document():
        image = Image.new("RGB", (560, 160), "#edf2f7")
        ImageDraw.Draw(image).text((22, 35), "SAMPLE SUPPORTING DOCUMENT\n\nAcademic demo placeholder. Contains no identity information.", fill="#25364d")
        output = io.BytesIO()
        image.save(output, format="PNG")
        return ContentFile(output.getvalue(), name="sample-supporting-document.png")

    def create_requests(self, accounts, created_files):
        citizen = accounts["citizen"]
        admin = accounts["admin"]
        collector = accounts["collector"]
        today = timezone.localdate()
        for reference, kind, title, category, target_status in RECORDS:
            record = ServiceRequest(
                reference=reference, owner=citizen, kind=kind, title=title,
                status="submitted", applicant_name="Anu Thomas",
                description="Fictional sample request for demonstrating the project workflow.",
                address=citizen.profile.address, ward=5, phone="9999999999",
                certificate_type=category if kind == "certificate" else "",
                category=category if kind != "certificate" else "",
                preferred_date=(today if target_status == "collected" else today + timedelta(days=2)) if kind == "waste" else None,
            )
            if kind == "certificate":
                record.attachment.save("sample-supporting-document.png", self.sample_document(), save=False)
                created_files.append((record.attachment.storage, record.attachment.name))
            try:
                record.full_clean()
            finally:
                # Validation reads stored files; close the handle for Windows.
                if record.attachment:
                    record.attachment.close()
            record.save()
            StatusUpdate.objects.create(request=record, actor=citizen, from_status="", to_status="submitted", note="Sample request created for the academic demonstration.")
            Notification.objects.create(user=citizen, request=record, title="Sample request received", message=f"The sample request {reference} is available for you to explore.")
            if target_status in {"approved", "under_review"}:
                record = transition_request(record, admin, {"status": "under_review", "note": "Sample documents are being reviewed in the demo."})
                if target_status == "approved":
                    transition_request(record, admin, {"status": "approved", "note": "Sample application approved for demonstration only."})
            elif target_status in {"in_progress", "resolved"}:
                record = transition_request(record, admin, {"status": "in_progress", "note": "The sample issue is being handled by the demonstration team."})
                if target_status == "resolved":
                    transition_request(record, admin, {"status": "resolved", "note": "Sample issue marked resolved to demonstrate closure tracking."})
            elif target_status in {"scheduled", "collected"}:
                record = transition_request(record, admin, {"status": "scheduled", "note": "Sample collection assignment; this is not a live pickup booking.", "assigned_to": collector, "scheduled_date": record.preferred_date})
                if target_status == "collected":
                    transition_request(record, collector, {"status": "collected", "note": "Sample collection marked complete for demonstration."})
