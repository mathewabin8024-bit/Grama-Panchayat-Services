"""Atomic service workflows; permission checks also apply outside HTTP views."""

from datetime import date

from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.db import transaction
from django.utils import timezone

from .models import Notification, Profile, ServiceRequest, StatusUpdate


def is_official(user):
    return bool(user and user.is_authenticated and user.is_active and (user.is_staff or user.is_superuser))


def is_collector(user):
    if not user or not user.is_authenticated or not user.is_active:
        return False
    try:
        return user.profile.role == Profile.Role.COLLECTOR
    except ObjectDoesNotExist:
        return False


S = ServiceRequest.Status
TRANSITIONS = {
    ServiceRequest.Kind.CERTIFICATE: {
        S.SUBMITTED: [S.UNDER_REVIEW, S.APPROVED, S.REJECTED, S.CANCELLED],
        S.UNDER_REVIEW: [S.APPROVED, S.REJECTED, S.CANCELLED],
        S.APPROVED: [S.REVOKED],
    },
    ServiceRequest.Kind.COMPLAINT: {
        S.SUBMITTED: [S.UNDER_REVIEW, S.IN_PROGRESS, S.RESOLVED, S.REJECTED, S.CANCELLED],
        S.UNDER_REVIEW: [S.IN_PROGRESS, S.RESOLVED, S.REJECTED, S.CANCELLED],
        S.IN_PROGRESS: [S.RESOLVED, S.REJECTED],
    },
    ServiceRequest.Kind.DISASTER: {
        S.SUBMITTED: [S.UNDER_REVIEW, S.IN_PROGRESS, S.RESOLVED, S.REJECTED, S.CANCELLED],
        S.UNDER_REVIEW: [S.IN_PROGRESS, S.RESOLVED, S.REJECTED, S.CANCELLED],
        S.IN_PROGRESS: [S.RESOLVED, S.REJECTED],
    },
    ServiceRequest.Kind.WASTE: {
        S.SUBMITTED: [S.UNDER_REVIEW, S.SCHEDULED, S.REJECTED, S.CANCELLED],
        S.UNDER_REVIEW: [S.SCHEDULED, S.REJECTED, S.CANCELLED],
        S.SCHEDULED: [S.COLLECTED, S.CANCELLED],
    },
}


def allowed_transitions(request_obj, user=None):
    """Return status values; omitted user supplies the workflow's complete choices."""
    choices = list(TRANSITIONS.get(request_obj.kind, {}).get(request_obj.status, []))
    if user is None or is_official(user):
        return choices
    if not user.is_authenticated or not user.is_active:
        return []
    if (is_collector(user) and request_obj.kind == ServiceRequest.Kind.WASTE
            and request_obj.assigned_to_id == user.pk and request_obj.status == S.SCHEDULED):
        return [S.COLLECTED]
    if request_obj.owner_id == user.pk and request_obj.status in {S.SUBMITTED, S.UNDER_REVIEW}:
        return [S.CANCELLED]
    return []


def validate_transition(request_obj, actor, cleaned_data):
    """Validate business rules for both form feedback and locked writes."""
    status = cleaned_data.get("status")
    if status not in allowed_transitions(request_obj, actor):
        raise ValidationError({"status": "This status change is not permitted. Refresh the request and try again."})
    note = (cleaned_data.get("note") or "").strip()
    if len(note) > 2000:
        raise ValidationError({"note": "Keep the note within 2,000 characters."})
    if status in {S.REJECTED, S.REVOKED} and not note:
        raise ValidationError({"note": "Give a reason for rejecting or revoking this request."})
    if status == S.APPROVED and request_obj.certificate_type in ('birth', 'death'):
        required = ['subject_name', 'event_date', 'event_place', 'applicant_relationship']
        if request_obj.certificate_type == 'birth':
            required.append('parent_one')
        if any(not getattr(request_obj, name) for name in required):
            raise ValidationError("Required birth or death details are missing; this certificate cannot be approved.")
        if request_obj.event_date > timezone.localdate():
            raise ValidationError("A future birth or death date cannot be approved.")
    if status == S.SCHEDULED:
        collector = cleaned_data.get("assigned_to")
        if not collector or not is_collector(collector):
            raise ValidationError({"assigned_to": "Select an active waste collector."})
        scheduled_date = cleaned_data.get("scheduled_date")
        if not isinstance(scheduled_date, date) or scheduled_date < timezone.localdate():
            raise ValidationError({"scheduled_date": "Choose today or a future collection date."})
    return status, note


@transaction.atomic
def create_request(form, user):
    if not user or not user.is_authenticated or not user.is_active:
        raise ValidationError("Log in with an active account before submitting a request.")
    if not form.is_valid():
        raise ValidationError("Correct the form errors before submitting this request.")
    record = form.save(commit=False)
    if record.pk:
        raise ValidationError("Use the request workflow to update an existing request.")
    record.owner = user
    record.applicant_name = (record.applicant_name or user.get_full_name() or user.username)[:150]
    record.status = S.SUBMITTED
    record.assigned_to = None
    record.scheduled_date = None
    record.issued_at = None
    record.full_clean()
    record.save()
    StatusUpdate.objects.create(request=record, actor=user, from_status="", to_status=S.SUBMITTED,
                                note="Request submitted by the citizen.")
    Notification.objects.create(user=user, request=record, title="Request received",
                                message=f"Your request {record.reference} has been received by the panchayat.")
    if record.kind == ServiceRequest.Kind.DISASTER:
        from django.contrib.auth import get_user_model
        from django.db.models import Q
        officials = get_user_model().objects.filter(Q(is_staff=True) | Q(is_superuser=True), is_active=True)
        Notification.objects.bulk_create([Notification(user=official, request=record,
            title=f"{record.get_severity_display()} disaster alert: {record.reference}",
            message=f"Citizen-reported {record.category} in ward {record.ward}. Review the report and respond.") for official in officials])
    return record


@transaction.atomic
def transition_request(request_obj, actor, cleaned_data):
    if not actor or not actor.is_authenticated or not actor.is_active:
        raise ValidationError("An active account is required to update a request.")
    # Lock only the request row: joining nullable assigned_to would fail on PostgreSQL.
    record = ServiceRequest.objects.select_for_update().get(pk=request_obj.pk)
    status, note = validate_transition(record, actor, cleaned_data)
    previous_status = record.status
    record.status = status
    if status == S.APPROVED:
        record.issued_at = timezone.now()
    if status == S.SCHEDULED:
        collector = cleaned_data["assigned_to"]
        # Fetch again so a stale form cannot assign a since-deactivated collector.
        collector = type(collector).objects.get(pk=collector.pk)
        if not is_collector(collector):
            raise ValidationError({"assigned_to": "This collector is no longer available."})
        record.assigned_to = collector
        record.scheduled_date = cleaned_data["scheduled_date"]
    record.save(update_fields=["status", "issued_at", "assigned_to", "scheduled_date", "updated_at"])
    if status == S.APPROVED:
        from .certificates import ensure_issued_document
        ensure_issued_document(record)
    if status == S.SCHEDULED:
        assignment_note = f"Collection scheduled for {record.scheduled_date:%d %b %Y}; assigned to {record.assigned_to.get_full_name() or record.assigned_to.username}."
        audit_note = f"{note}\n{assignment_note}".strip()[:2000]
    else:
        audit_note = note
    StatusUpdate.objects.create(request=record, actor=actor, from_status=previous_status,
                                to_status=status, note=audit_note)
    message = f"Your request {record.reference} is now {record.get_status_display().lower()}."
    if status == S.SCHEDULED:
        message += f" Collection date: {record.scheduled_date:%d %b %Y}."
    if note:
        message += f" {note}"
    Notification.objects.create(user=record.owner, request=record, title=f"Request {record.get_status_display().lower()}",
                                message=message[:2000])
    if status == S.SCHEDULED:
        Notification.objects.create(user=record.assigned_to, request=record, title="New waste collection assigned",
                                    message=f"Collect waste for {record.reference}, ward {record.ward}, on {record.scheduled_date:%d %b %Y}.")
    return record
