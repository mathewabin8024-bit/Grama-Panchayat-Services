"""Durable SMS outbox. Provider submission is not proof of delivery or safety."""
import ipaddress
import base64
import json
import re
from datetime import timedelta
from zoneinfo import ZoneInfo
from urllib import request, parse, error
from django.conf import settings
from django.utils import timezone
from .models import SafetySMS


def normalize_phone(value):
    value = re.sub(r'[\s()\-]', '', value or '')
    if re.fullmatch(r'[0-9]{10}', value):
        value = '+' + settings.SMS_DEFAULT_COUNTRY_CODE + value
    if not re.fullmatch(r'\+[1-9][0-9]{7,14}', value):
        return ''
    return value


def issue_body(alert):
    return (f'Emergency alert: Extreme\n[Sending date and time IST]\n\n'
            f'{alert.title}\n'
            f'Area: {alert.affected_area}\n'
            f'Action: {alert.get_action_display()}\n'
            f'Safe place: {alert.safe_place}\n'
            f'Instructions: {alert.sms_instructions or alert.instructions}\n'
            f'Helpline: {alert.contact}\n'
            f'— Panchayat')


def queue_sms(alert, event='issue'):
    if event != 'issue':
        return
    backend = settings.SMS_BACKEND or 'disabled'
    body = issue_body(alert)
    for recipient in alert.recipients.select_related('user__profile'):
        phone = normalize_phone(recipient.user.profile.phone)
        status = 'pending' if phone else 'invalid_number'
        detail = '' if phone else 'Missing/invalid mobile number; update the citizen profile before future alerts.'
        if len(body) > 1600:
            status, detail = 'failed', 'SMS exceeds 1600 characters. No truncated safety instructions were sent.'
        expires_at = timezone.now() + timedelta(minutes=15)
        sms, created = SafetySMS.objects.get_or_create(
            alert=alert,
            user=recipient.user,
            event=event,
            defaults={
                'backend': backend,
                'phone': phone,
                'body': body,
                'status': status,
                'error': detail,
                'expires_at': expires_at,
            },
        )


def local_gateway_url_valid():
    try:
        url = parse.urlsplit(settings.TRACCAR_SMS_URL)
        ip = ipaddress.ip_address(url.hostname)
        return (url.scheme in ['http', 'https'] and ip.is_private and not ip.is_loopback
                and not ip.is_link_local and not ip.is_unspecified and not ip.is_multicast
                and not url.username and not url.password and not url.query and not url.fragment
                and url.path in ['', '/'] and bool(url.port))
    except (ValueError, TypeError):
        return False


def traccar_request(phone, body):
    if not local_gateway_url_valid() or not settings.TRACCAR_SMS_KEY:
        raise ValueError('Local gateway configuration incomplete')
    class NoRedirect(request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None
    req = request.Request(settings.TRACCAR_SMS_URL,
        data=json.dumps({'to': phone, 'message': body}).encode(),
        headers={'Authorization': settings.TRACCAR_SMS_KEY, 'Content-Type': 'application/json'})
    # Connect directly on the private network; never send the key through a proxy or redirect.
    opener = request.build_opener(request.ProxyHandler({}), NoRedirect())
    with opener.open(req, timeout=15) as response:
        if not 200 <= response.status < 300:
            raise ValueError('Gateway did not accept the request')


def configured():
    if settings.SMS_BACKEND == 'traccar':
        return bool(local_gateway_url_valid() and settings.TRACCAR_SMS_KEY)
    return settings.SMS_BACKEND == 'twilio' and bool(
        re.fullmatch(r'AC[0-9a-fA-F]{32}', settings.TWILIO_ACCOUNT_SID) and
        settings.TWILIO_AUTH_TOKEN and (settings.TWILIO_FROM_NUMBER or settings.TWILIO_MESSAGING_SERVICE_SID))


def provider_request(payload=None, sid=''):
    account = settings.TWILIO_ACCOUNT_SID
    if sid and not re.fullmatch(r'SM[0-9a-fA-F]{32}', sid):
        raise ValueError('Invalid provider message identifier')
    url = f'https://api.twilio.com/2010-04-01/Accounts/{account}/Messages' + (f'/{sid}' if sid else '') + '.json'
    auth = base64.b64encode(f'{account}:{settings.TWILIO_AUTH_TOKEN}'.encode()).decode()
    req = request.Request(url, data=parse.urlencode(payload).encode() if payload is not None else None,
        headers={'Authorization': 'Basic ' + auth})
    with request.urlopen(req, timeout=15) as response:
        return json.load(response)


def process_outbox():
    now = timezone.now()
    SafetySMS.objects.filter(status='pending',event='closure').update(
        status='cancelled',error='Closure SMS disabled; updates appear on the website only.',updated_at=now)
    # A process lost during a submission may have sent it: never retry blindly.
    SafetySMS.objects.filter(status='sending',updated_at__lt=now-timedelta(minutes=2)).update(
        status='unknown',error='Submission interrupted; check provider logs before any resend.',updated_at=now)
    SafetySMS.objects.filter(status='pending',expires_at__lte=now).update(status='expired',error='Not submitted within 15 minutes. Issue a fresh alert if still needed.',updated_at=now)
    SafetySMS.objects.filter(status='pending',event='issue',alert__closed_at__isnull=False).update(status='cancelled',error='Alert closed before submission.',updated_at=now)
    backend = settings.SMS_BACKEND
    if backend != 'simulation' and not configured():
        return 0
    count = 0
    for pk in SafetySMS.objects.filter(status='pending',event='issue',backend=backend,next_attempt__lte=now).values_list('pk',flat=True)[:100]:
        if not SafetySMS.objects.filter(pk=pk,status='pending').update(status='sending',updated_at=timezone.now()):
            continue
        sms = SafetySMS.objects.select_related('alert').get(pk=pk)
        if sms.expires_at <= timezone.now() or (sms.event == 'issue' and sms.alert.closed_at):
            sms.status='cancelled';sms.save(update_fields=['status','updated_at']);continue
        if sms.body.startswith('Emergency alert: Extreme\n'):
            lines = sms.body.split('\n')
            lines[1] = timezone.now().astimezone(ZoneInfo('Asia/Kolkata')).strftime('%d %b %Y, %I:%M %p IST')
            sms.body = '\n'.join(lines)
            # Save the exact submission text before contacting the gateway.
            sms.save(update_fields=['body', 'updated_at'])
        sms.attempts += 1
        if backend == 'simulation':
            sms.status='simulated';sms.error='Simulation only: no SMS sent.'
        elif backend == 'traccar':
            try:
                traccar_request(sms.phone, sms.body)
                sms.status='submitted'
                sms.error='Phone gateway accepted the request. Check the phone for send/delivery status; receipt is not confirmed here.'
            except error.HTTPError as exc:
                sms.status='failed' if 400 <= exc.code < 500 else 'unknown'
                sms.error=f'Phone gateway HTTP {exc.code}. Check local API key/app. No automatic resend.'
            except Exception:
                sms.status='unknown'
                sms.error='Phone connection failed or response uncertain. Check the phone before resending.'
        else:
            payload={'To':sms.phone,'Body':sms.body,'ValidityPeriod':'900'}
            if settings.TWILIO_MESSAGING_SERVICE_SID: payload['MessagingServiceSid']=settings.TWILIO_MESSAGING_SERVICE_SID
            else: payload['From']=settings.TWILIO_FROM_NUMBER
            try:
                result=provider_request(payload)
                sid=result.get('sid','')
                if not re.fullmatch(r'SM[0-9a-fA-F]{32}',sid): raise ValueError('Missing message identifier')
                sms.provider_id=sid;sms.status='submitted';sms.error=''
            except error.HTTPError as exc:
                if exc.code == 429 and sms.attempts < 3:
                    sms.status='pending';sms.next_attempt=timezone.now()+timedelta(seconds=60*sms.attempts)
                    sms.error='Provider rate limit; retry scheduled.'
                else:
                    sms.status='unknown' if exc.code >= 500 else 'failed'
                    sms.error=f'Provider HTTP {exc.code}; review configuration/logs. No automatic resend.'
            except Exception:
                sms.status='unknown';sms.error='No conclusive provider response. Check provider logs; not automatically resent to avoid duplicates.'
        sms.save();count+=1
    if backend == 'twilio' and configured():
        for sms in SafetySMS.objects.filter(status='submitted',backend='twilio').exclude(provider_id='').order_by('updated_at')[:100]:
            try:
                result=provider_request(sid=sms.provider_id)
                state=result.get('status')
                if state in ['delivered','undelivered','failed','canceled']:
                    sms.status='failed' if state=='canceled' else state
                    sms.error=('Provider reports '+state) if state!='delivered' else ''
                    sms.save(update_fields=['status','error','updated_at'])
            except Exception:
                pass  # Retain submitted until a later status query succeeds; never resend.
            SafetySMS.objects.filter(pk=sms.pk).update(updated_at=timezone.now())
    return count
