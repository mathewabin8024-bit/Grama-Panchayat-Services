"""Local, role-scoped interface translations; stored citizen content is untouched."""
import json
from pathlib import Path
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseBadRequest, HttpResponseForbidden
from django.shortcuts import redirect
from django.utils import translation
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

CATALOG = json.loads(Path(__file__).with_name('malayalam.json').read_text(encoding='utf-8'))

def ui(value):
    text = str(value or '')
    return CATALOG.get(text, text) if translation.get_language() == 'ml' else text

class PortalLanguageMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = request.user
        language = 'en'
        if user.is_authenticated and not (user.is_staff or user.is_superuser):
            language = getattr(getattr(user, 'profile', None), 'language', 'en')
        request.LANGUAGE_CODE = language
        with translation.override(language):
            return self.get_response(request)

@login_required
@require_POST
def set_language(request):
    if request.user.is_staff or request.user.is_superuser:
        return HttpResponseForbidden('Language switching is available to citizens and collectors.')
    language = request.POST.get('language')
    if language not in ('en', 'ml'):
        return HttpResponseBadRequest('Unsupported language.')
    profile = request.user.profile
    profile.language = language
    profile.save(update_fields=['language'])
    target = request.POST.get('next', '')
    if not url_has_allowed_host_and_scheme(target, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        target = '/dashboard/'
    return redirect(target or '/dashboard/')
