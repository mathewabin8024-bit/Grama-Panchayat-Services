"""Forms expose only fields a citizen or authorized official may change."""

from datetime import timedelta

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import Profile, ServiceRequest
from .services import allowed_transitions, validate_transition
from .validators import validate_phone


User = get_user_model()


def style_fields(form):
    for field in form.fields.values():
        css = "form-select" if isinstance(field.widget, forms.Select) else "form-control"
        field.widget.attrs.setdefault("class", css)
        if isinstance(field.widget, forms.Textarea):
            field.widget.attrs.setdefault("rows", 3)


class RegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150, required=False)
    email = forms.EmailField()
    phone = forms.CharField(max_length=25, validators=[validate_phone])
    address = forms.CharField(max_length=1000, widget=forms.Textarea)
    ward = forms.IntegerField(min_value=1, max_value=100, initial=1)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ["username", "first_name", "last_name", "email", "phone", "address", "ward", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style_fields(self)
        self.fields["username"].widget.attrs["autocomplete"] = "username"
        self.fields["email"].widget.attrs["autocomplete"] = "email"
        for name in ["password1", "password2"]:
            self.fields[name].widget.attrs["autocomplete"] = "new-password"

    @transaction.atomic
    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
            profile, _ = Profile.objects.get_or_create(user=user)
            for name in ["phone", "address", "ward"]:
                setattr(profile, name, self.cleaned_data[name])
            profile.save()
            user.profile = profile
        return user


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["phone", "address", "ward"]
        widgets = {"address": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.required = True
        self.fields["phone"].help_text = "Used for safety SMS. Prefer international format, for example +919876543210. A 10-digit number uses the configured default country code."
        style_fields(self)


COMPLAINT_CATEGORIES = [
    ("roads", "Roads and street lighting"),
    ("water", "Water supply"),
    ("sanitation", "Drainage and sanitation"),
    ("waste", "Waste and cleanliness"),
    ("other", "Other civic issue"),
]
WASTE_CATEGORIES = [
    ("household", "Household waste"),
    ("recyclable", "Dry and recyclable waste"),
    ("garden", "Garden waste"),
    ("bulky", "Bulky household waste"),
]


class RequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ["title", "description", "applicant_name", "certificate_type", "category", "severity",
                  "address", "ward", "phone", "preferred_date", "attachment",
                  "subject_name", "sex", "registration_number", "registration_date", "event_date", "event_place", "applicant_relationship", "parent_one", "parent_two"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "address": forms.Textarea(attrs={"rows": 3}),
            "registration_date": forms.DateInput(attrs={"type": "date"}),
            "event_date": forms.DateInput(attrs={"type": "date"}),
            "preferred_date": forms.DateInput(attrs={"type": "date"}),
            "attachment": forms.FileInput(attrs={"accept": ".pdf,.png,.jpg,.jpeg"}),
        }

    def __init__(self, kind, user, *args, **kwargs):
        if kind not in ServiceRequest.Kind.values:
            raise ValueError("Unknown request type.")
        self.kind = kind
        self.user = user
        super().__init__(*args, **kwargs)
        self.instance.kind = kind
        self.instance.owner = user
        profile, _ = Profile.objects.get_or_create(user=user)
        for name in ["address", "ward", "phone"]:
            self.fields[name].initial = getattr(profile, name)
        self.fields["applicant_name"].initial = user.get_full_name() or user.username
        fields_for_kind = {
            ServiceRequest.Kind.CERTIFICATE: ["certificate_type", "applicant_name", "applicant_relationship", "subject_name", "sex", "registration_number", "registration_date", "event_date", "event_place", "parent_one", "parent_two", "address", "ward", "phone", "description", "attachment"],
            ServiceRequest.Kind.COMPLAINT: ["title", "category", "description", "address", "ward", "phone", "attachment"],
            ServiceRequest.Kind.DISASTER: ["title", "category", "severity", "description", "address", "ward", "phone", "attachment"],
            ServiceRequest.Kind.WASTE: ["category", "address", "ward", "phone", "preferred_date", "description"],
        }
        self.fields = {name: self.fields[name] for name in fields_for_kind[kind]}
        for name in ["address", "ward", "phone"]:
            self.fields[name].required = True
        if kind == ServiceRequest.Kind.CERTIFICATE:
            self.fields["certificate_type"].required = True
            self.fields["applicant_name"].required = True
            self.fields["attachment"].required = True
            self.fields["attachment"].label = "Supporting document"
            self.fields["description"].label = "Purpose / additional details"
            self.fields["applicant_name"].label = "Applicant / requester name"
            self.fields["certificate_type"].help_text = "Birth, death, residence, property ownership or general certificate."
            for name in ["subject_name", "sex", "registration_number", "registration_date", "event_date", "event_place", "applicant_relationship", "parent_one", "parent_two"]:
                field = self.fields[name]
                field.certificate_types = "birth death"
                field.conditionally_required = name in ["subject_name", "event_date", "event_place", "applicant_relationship"]
                field.required = False  # Conditional requirements are enforced below on the server.
                field.help_text = "Required for birth certificates." if name == "parent_one" else (
                    "Optional." if name == "parent_two" else "Required for birth and death certificates.")
            self.fields['parent_one'].label = 'Father / husband / guardian name'
            self.fields['parent_two'].label = 'Mother / second parent / guardian name'
            for name in ['sex','registration_number','registration_date']:
                self.fields[name].help_text = 'Enter as recorded in the supporting birth or death record, if available.'
            self.fields['registration_date'].widget.attrs['max'] = timezone.localdate().isoformat()
            self.fields["event_date"].widget.attrs["max"] = timezone.localdate().isoformat()
        elif kind == ServiceRequest.Kind.DISASTER:
            self.fields["category"] = forms.ChoiceField(choices=[("flood", "Flood / waterlogging"), ("storm", "Storm / strong wind"), ("landslide", "Landslide"), ("heat", "Extreme heat"), ("fire", "Fire"), ("other", "Other hazard")])
            self.fields["severity"].required = True
            self.fields["description"].required = True
            self.fields["address"].label = "Incident location / nearest landmark"
            self.fields["description"].label = "What happened and who is affected?"
        elif kind == ServiceRequest.Kind.COMPLAINT:
            self.fields["category"] = forms.ChoiceField(choices=COMPLAINT_CATEGORIES)
            self.fields["description"].required = True
        else:
            self.fields["category"] = forms.ChoiceField(choices=WASTE_CATEGORIES)
            self.fields["preferred_date"].required = True
            self.fields["preferred_date"].widget.attrs.update({
                "min": timezone.localdate().isoformat(),
                "max": (timezone.localdate() + timedelta(days=90)).isoformat(),
            })
            self.fields["preferred_date"].help_text = "Choose a date within the next 90 days. The panchayat confirms the collection date."
        if "attachment" in self.fields:
            self.fields["attachment"].help_text = "PDF, PNG, or JPEG. Maximum size: 5 MB. Accessible only to you and authorized officials."
        style_fields(self)

    def clean_preferred_date(self):
        value = self.cleaned_data.get("preferred_date")
        today = timezone.localdate()
        if value and not today <= value <= today + timedelta(days=90):
            raise ValidationError("Choose a date from today to 90 days from today.")
        return value

    def clean(self):
        data = super().clean()
        if self.kind == ServiceRequest.Kind.CERTIFICATE:
            value = data.get("certificate_type", "")
            self.instance.title = dict(ServiceRequest.CertificateType.choices).get(value, "Certificate application")
            event_fields = ["subject_name", "sex", "registration_number", "registration_date", "event_date", "event_place", "applicant_relationship"]
            if value in ["birth", "death"]:
                for name in ["subject_name", "event_date", "event_place", "applicant_relationship"] + (["parent_one"] if value == "birth" else []):
                    if name in data and not data[name]:
                        self.add_error(name, "This detail is required for the selected certificate.")
                if data.get("event_date") and data["event_date"] > timezone.localdate():
                    self.add_error("event_date", "The date of birth or death cannot be in the future.")
                registration_date = data.get('registration_date')
                if registration_date and registration_date > timezone.localdate():
                    self.add_error('registration_date', 'Registration date cannot be in the future.')
                if registration_date and data.get('event_date') and registration_date < data['event_date']:
                    self.add_error('registration_date', 'Registration cannot precede the birth or death.')
            else:
                for name in event_fields:
                    data[name] = None if name in ["event_date", "registration_date"] else ""
            if value not in ["birth", "death"]:
                data["parent_one"] = data["parent_two"] = ""
        elif self.kind == ServiceRequest.Kind.WASTE:
            self.instance.title = dict(WASTE_CATEGORIES).get(data.get("category"), "Waste") + " collection"
        return data


class TransitionForm(forms.Form):
    status = forms.ChoiceField(label="New status")
    note = forms.CharField(max_length=2000, required=False, widget=forms.Textarea(attrs={"rows": 3}),
                           help_text="Visible to the citizen. Required when rejecting or revoking a request.")
    assigned_to = forms.ModelChoiceField(queryset=User.objects.none(), required=False, label="Waste collector")
    scheduled_date = forms.DateField(required=False, widget=forms.DateInput(attrs={"type": "date"}), label="Collection date")

    def __init__(self, request_obj, *args, **kwargs):
        self.request_obj = request_obj
        self.actor = kwargs.pop("actor", None)
        super().__init__(*args, **kwargs)
        labels = dict(ServiceRequest.Status.choices)
        self.fields["status"].choices = [(status, labels[status]) for status in allowed_transitions(request_obj, self.actor)]
        if request_obj.kind == ServiceRequest.Kind.WASTE:
            self.fields["assigned_to"].queryset = User.objects.filter(is_active=True, profile__role=Profile.Role.COLLECTOR).order_by("first_name", "username")
            self.fields["assigned_to"].initial = request_obj.assigned_to_id
            self.fields["scheduled_date"].initial = request_obj.scheduled_date or request_obj.preferred_date
            self.fields["scheduled_date"].widget.attrs["min"] = timezone.localdate().isoformat()
        else:
            self.fields.pop("assigned_to")
            self.fields.pop("scheduled_date")
        style_fields(self)

    def clean(self):
        data = super().clean()
        if "status" in data:
            validate_transition(self.request_obj, self.actor, data)
        return data


class CertificateFileCheckForm(forms.Form):
    certificate_file = forms.FileField(label="Certificate PDF", help_text="Upload the original downloaded PDF, up to 5 MB. Used only for this check.", widget=forms.FileInput(attrs={"accept": ".pdf,application/pdf"}))

    def clean_certificate_file(self):
        upload = self.cleaned_data["certificate_file"]
        from pathlib import Path
        if upload.size > 5 * 1024 * 1024:
            raise ValidationError("Choose a PDF no larger than 5 MB.")
        if Path(upload.name).suffix.lower() != ".pdf":
            raise ValidationError("Choose the downloaded PDF certificate.")
        header = upload.read(5)
        upload.seek(0)
        if header != b"%PDF-":
            raise ValidationError("This file is not a PDF.")
        return upload
