$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$projectPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $projectPython)) {
    $candidates = @(
        (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'),
        'python', 'py'
    )
    $basePython = $null
    foreach ($candidate in $candidates) {
        try {
            $null = & $candidate -c 'import sys; assert sys.version_info >= (3, 10)' 2>$null
            if ($LASTEXITCODE -eq 0) { $basePython = $candidate; break }
        } catch { }
    }
    if (-not $basePython) { throw 'Install Python 3.12 or newer, then run this launcher again.' }
    & $basePython -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the project virtual environment.' }
}
& $projectPython -c "import importlib.util, sys; sys.exit(0 if all(importlib.util.find_spec(p) for p in ['django','qrcode','reportlab','dotenv']) else 1)"
if ($LASTEXITCODE -ne 0) {
    & $projectPython -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check your internet connection and retry.' }
}
$useMysql = $env:DB_ENGINE -eq 'mysql'
if (Test-Path -LiteralPath '.env') {
    $useMysql = $useMysql -or [bool](Select-String -LiteralPath '.env' -Pattern '^\s*DB_ENGINE\s*=\s*mysql\s*$' -Quiet)
}
if ($useMysql) {
    & $projectPython -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('MySQLdb') else 1)"
    if ($LASTEXITCODE -ne 0) {
        & $projectPython -m pip install -r requirements-mysql.txt
        if ($LASTEXITCODE -ne 0) { throw 'MySQL driver installation failed.' }
    }
}
& $projectPython manage.py migrate --noinput
if ($LASTEXITCODE -ne 0) { throw 'Database setup failed. Check the database settings in .env.' }
& $projectPython manage.py seed_demo
if ($LASTEXITCODE -ne 0) { throw 'Demo seeding stopped to preserve existing accounts. Read the message above.' }
& $projectPython manage.py freeze_certificates
if ($LASTEXITCODE -ne 0) { throw 'Could not prepare existing certificate originals.' }
Write-Host ''
Write-Host 'Open http://127.0.0.1:8000/ in your browser. Press Ctrl+C to stop.' -ForegroundColor Cyan
$smsWorker = Start-Process -FilePath $projectPython -ArgumentList @('manage.py','process_safety_sms','--watch') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru
try {
    & $projectPython manage.py runserver 127.0.0.1:8000 --noreload
} finally {
    if ($smsWorker -and -not $smsWorker.HasExited) { Stop-Process -Id $smsWorker.Id -ErrorAction SilentlyContinue }
}
