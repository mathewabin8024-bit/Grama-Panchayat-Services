# Validation record

Verified on this local Windows workspace using Python 3.12.14 and Django 5.2.17.

- `manage.py check`: no issues.
- Database migrations: applied successfully using SQLite.
- `manage.py test portal`: 79 tests passed.
- `seed_demo`: 3 sample accounts, 9 requests and 2 announcements; repeated invocation preserved accounts and existing workflow states.
- Citizen sign-in, request list, approved certificate page and application form inspected in the in-app browser.
- Application form checked at a mobile viewport: no page-level horizontal overflow.
- Administrator and collector dashboards, lists, notifications and profiles returned HTTP 200 through the Django test client; administrator reports, announcement creation and administration pages also rendered successfully.
- Generated certificate PDF rendered and visually inspected: a single page with readable fields, QR, verification code and link, and demonstration labels.
- Added regression tests for birth/death requirements, immutable PDF downloads, matching/altered/wrong/revoked certificate checks, poster upload validation, draft image privacy, notice editing and role restrictions.
- Birth and death PDF previews each generated as one page; birth preview visually inspected.
- MySQL driver installed and configuration supplied; no live MySQL integration test was performed.

- Android gateway tests cover local URL configuration, authentication payload, provider isolation, submitted vs. delivered status, uncertain-response duplicate prevention and idempotent queueing.

No claims of production readiness, government authorization, cryptographic document signatures, push notification delivery, or encryption at rest are made.

- Safety-alert tests cover official-only issuance/closure, ward and all-citizen targeting, recipient privacy, notification links, persistent warnings, idempotent acknowledgement, required safe-place details, closure audit and notifications, and removal of citizen hazard submission.
- QR scanner checks decode a generated certificate QR using bundled jsQR and exercise the image handler, local-only result navigation, old-host QR links, unrelated QR rejection and missing-camera fallback.
- Physical camera scanning has not been verified with actual camera hardware.

- SMS tests cover number formatting, persistent unique outbox entries, disabled/simulated modes, mocked provider submission and delivery polling, bounded rate-limit retries, ambiguous-response duplicate prevention, invalid/expired/closed messages, required concise instructions, web issuance SMS, website-only closure notifications and cancellation of queued closure SMS. Live Twilio configuration was checked but the trial rejected custom text. After the hotspot address was updated and VPN blocking was resolved, the Android gateway accepted one explicitly labelled demo SMS on 1 October 2026. Handset delivery is not independently confirmed.

- Birth/death reference-style layouts rendered and visually checked as one-page A4 sample PDFs. Added sex, registration number/date, and death parent fields; registration dates cannot precede the event or be in the future. Existing issued originals are preserved. Signature space is labelled ABIN MATHEW, Head Officer; the supplied signature is embedded and the website logo appears at the top left.
