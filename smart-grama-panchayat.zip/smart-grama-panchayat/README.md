# Smart Digital Grama Panchayat Services

A working Django project based on the supplied MCA review slides. This is an academic demonstration with sample data, not an official government service.

## Start on Windows

Double-click **START_DEMO.cmd** in this folder. The first run creates a virtual environment, installs the dependencies, migrates the database, and adds sample accounts. Leave its terminal open, then visit **http://127.0.0.1:8000/**.

Python 3.12 or 3.13 is recommended. The launcher can also use the Python runtime bundled with Codex on this computer. A working internet connection is needed for the first dependency installation. Later launches reuse the environment.

| Role | Username | Password |
| --- | --- | --- |
| Panchayat administrator | `admin` | `Demo@Grama2026!` |
| Citizen | `citizen` | `Demo@Grama2026!` |
| Waste collection staff | `collector` | `Demo@Grama2026!` |

These credentials apply only to accounts created by `seed_demo`. The command never resets existing passwords. Use sample information in the demo.

## Implemented features

- Citizen registration, password validation, login/logout and contact profile.
- Separate citizen, official and collection staff workspaces.
- Birth, death, residence, property ownership and general certificate applications with private supporting documents.
- Officials review, approve, reject or revoke certificates, with an audit history.
- Downloadable demonstration certificate PDFs with scannable QR verification links.
- Public verification shows certificate reference, type, issue date and applicant initials. It never exposes supporting files, full addresses or phone numbers.
- Categorized complaints, progress updates and resolution notes.
- Waste pickup requests, confirmed schedules, staff assignment and completion.
- Searchable request lists, filters and pagination.
- In-app notifications; the unread badge checks for changes every 20 seconds while the page is open.
- Digital notice board with PNG/JPEG posters, ceremony/event categories, dates, venues, editing and publish controls.
- Administrator reports, CSV export and user administration.
- Stored records and uploads persist between server restarts.

## Technical stack

Python, Django 5.2, server-rendered HTML, local Bootstrap 5 CSS, custom CSS, JavaScript, QRCode/Pillow and ReportLab. MySQL configuration is provided. SQLite is the zero-setup demo database. No Node.js build or external CDN is required to use the pages.

## Manual setup

Run these commands from this folder:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe manage.py migrate
.venv\Scripts\python.exe manage.py seed_demo
.venv\Scripts\python.exe manage.py freeze_certificates
.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
```

`requirements-lock.txt` records the exact package versions used for verification. `requirements.txt` allows compatible maintenance releases. MySQL users should install `requirements-mysql.txt` as described below.

## Connect MySQL

Install and start MySQL 8.0.11 or later. In the MySQL shell, create a database and dedicated application user (choose your own password):

```sql
CREATE DATABASE smart_grama CHARACTER SET utf8mb4;
CREATE USER 'grama'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
GRANT ALL PRIVILEGES ON smart_grama.* TO 'grama'@'localhost';
```

Copy `.env.example` to `.env`, set `DB_ENGINE=mysql`, then set `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST` and `DB_PORT` to match your server. Generate a secret with `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"` inside the virtual environment and put it in `DJANGO_SECRET_KEY`.

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-mysql.txt
.venv\Scripts\python.exe manage.py migrate
.venv\Scripts\python.exe manage.py seed_demo
.venv\Scripts\python.exe manage.py freeze_certificates
.venv\Scripts\python.exe manage.py runserver
```

Switching databases does not transfer existing SQLite records. Seed a fresh demonstration database or perform a deliberate data migration if records need to be retained. The MySQL database user needs permission to create a test database when running Django tests against MySQL.

## Demonstrate the project

1. Sign in as `citizen`. Submit a certificate application with a sample PNG, JPEG or PDF (up to 5 MB).
2. Copy the request reference, then sign out and sign in as `admin`.
3. Open the request, select **Approved**, add a note and save the update.
4. Sign in as `citizen`. Open the request, inspect its timeline and download the certificate PDF.
5. Follow the QR link to the public verification page. Revoke the certificate as `admin` to demonstrate that the same link stops validating it.
6. Submit a complaint and change its status as `admin` to demonstrate tracking and notifications.
7. Submit a waste request. Schedule it as `admin`, assign `collector`, then sign in as `collector` and mark it collected.
8. Open the administrator reports and export the CSV. Create and publish an announcement.

For a phone to scan a QR code, it must reach the running server. Set `PUBLIC_BASE_URL` to a reachable LAN address or HTTPS deployment URL and include that host in `DJANGO_ALLOWED_HOSTS`. A localhost QR link works only on the same computer. Do not expose the demo accounts to the public internet.

## User and staff management

The seeded administrator can open `/admin/` to manage accounts. New public registrations always become citizens. For a collector, create a user and edit their profile role to **Waste collector**. For an official, enable **Staff status** on the user. Only trusted administrators should receive **Superuser status**. Officials manage service decisions through the project dashboard; request and audit records in Django admin are read-only so decisions go through the workflow.

## Project structure

```text
config/                 Django settings, root routes and WSGI entry point
portal/models.py        Profiles, requests, audit history, notifications, notices
portal/forms.py         Registration, request and transition validation
portal/services.py      Atomic status transitions and notifications
portal/views.py         Role-protected pages, downloads, verification and reports
portal/tests.py         Workflow and access-control regression tests
portal/migrations/      Database schema migrations
portal/management/      Sample data command
templates/              Django HTML templates
static/                 Local CSS, JavaScript and favicon
private_uploads/        Generated at runtime; not a public static/media folder
```

Read `PROJECT_GUIDE.md` for the database design, workflows and viva preparation.

## Tests

```powershell
.venv\Scripts\python.exe manage.py check
.venv\Scripts\python.exe manage.py test portal
```

## Scope and deployment notes

Certificate types are demonstration choices: birth, death, residence, property ownership and general. Replace the choices and required evidence with your institution's agreed project requirements. The system does not integrate government records, digital signatures, payment gateways, email or browser push delivery. Optional SMS requires an Android gateway or provider setup. Notifications currently use database records and browser polling. The architecture slide mentions AES encryption; this version hashes passwords using Django and authorizes private file access, but does not encrypt the database or upload files at rest.

Before a real deployment: remove demo accounts/data, set `DEMO_MODE=False`, `DJANGO_DEBUG=False`, a unique secret and exact allowed hosts, configure HTTPS, serve static files with a production web server, and run `manage.py check --deploy`. Keep `private_uploads` outside any public web root and include it in protected backups. Add login rate limiting and any institution-specific operational controls. This project has not been validated as a legally authoritative certificate-issuing system.

Framework references: [Django 5.2 documentation](https://docs.djangoproject.com/en/5.2/), [Django MySQL notes](https://docs.djangoproject.com/en/5.2/ref/databases/#mysql-notes), [QRCode](https://pypi.org/project/qrcode/).

## New certificate and notice board features

Birth and death applications collect the subject name, event date and place, and requester relationship. Birth applications additionally require one parent/guardian name; a second is optional. Future event dates are rejected.

Approval saves a fixed original PDF and its SHA-256 fingerprint. Scanning its QR checks the current record status. Upload the downloaded PDF on that verification page to check whether it exactly matches the issued original. A copied QR alone cannot establish that the surrounding document is unchanged. Edited PDFs, re-saved copies and scans will not match the original file. Verification uploads are checked without being saved.

For an existing installation, back up the database and private_uploads, apply migrations, then run `manage.py freeze_certificates`. Previously downloaded certificates should be downloaded again to obtain the newly stored original. Set PUBLIC_BASE_URL before issuing certificates: stored PDFs retain their original QR URL.

To publish a poster: sign in as admin, open **Notice board**, select **Add a notice**, enter the title and description, select Ceremony/Meeting/Event as appropriate, and optionally add the date, venue and a PNG/JPEG image up to 5 MB. Publish immediately or leave it as a draft. Use Edit to replace/remove a poster; unpublishing also blocks public access to its image.

## Scan QR codes and report disasters

Open **Verify certificate** and select **Scan with camera**, grant camera permission and point at the certificate QR. Alternatively select **Scan QR from image** and choose a PNG, JPEG or WebP screenshot/photo (up to 10 MB). Decoding happens locally in the browser; a recognized QR opens this portal's verification result automatically. QR codes containing older local hostnames are mapped to this portal, not followed to another site. The manual code option remains available.

Camera access requires HTTPS or localhost and browser permission. On a phone, localhost refers to the phone itself; use a reachable HTTPS deployment for camera scanning. Image scanning is available when a camera cannot be used. An approved QR confirms the database record; use the existing PDF comparison to check that the whole document is unchanged.

From **Weather & disaster alerts**, an administrator chooses **Issue a safety alert**, selects Evacuate now or Prepare to relocate, specifies the affected area, recipient ward (blank for all wards), safe shelter, relocation instructions and official contact. Issuing creates notifications and a persistent red warning for the active citizen accounts selected at issue time. The open portal checks for warning changes every 15 seconds. Recipients can acknowledge reading; officials see acknowledgement counts. Acknowledgement never means a citizen has relocated or reached safety.

Only officials can issue and close alerts. Closing requires an explanation, records the actor/time and notifies recipients. Closed alerts remain in history. Citizens cannot publish warnings. The earlier citizen hazard submission route now redirects to this official-alert board; existing legacy service records are preserved. Ward targeting uses registered profiles, not live geolocation. Website delivery is active. A durable SMS outbox supports an Android Traccar SMS Gateway or Twilio. The distributed example disables real SMS until configured. See SMS_SETUP.md. There are no phone calls or browser background push notifications.

Scanner dependencies: bundled [jsQR 1.4.0](https://github.com/cozmo/jsQR), Apache-2.0 license included in static/vendor. [Browser camera requirements](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia).

## Mobile SMS

Read **SMS_SETUP.md** to enable SMS alongside website safety alerts. The recipient can receive SMS without mobile data, provided cellular service works. Real sending is disabled until configured. START_DEMO starts the SMS worker with the website.

## Birth and death certificate layout

Newly issued birth/death PDFs use a centered heading, labelled record details, one signature block (ABIN MATHEW, Head Officer) and QR verification. Registration details are entered from supporting records; missing values are shown as Not recorded. The supplied signature is embedded with a transparent background; the website logo appears at the top left. Existing issued PDF originals remain unchanged to preserve their verification hashes.

All five certificate types now share the top-left Smart Grama brand, centered title, record-detail table, Head Officer signature and QR verification layout. Residence, ownership and general certificates use type-specific statements and the approved application details. Existing issued originals remain unchanged.

### Citizen and collector language support
The header has a large English / മലയാളം switch for citizen and waste collector accounts. The selected language is stored in the user's profile and persists after signing out. Admin screens remain English. Malayalam interface translations are bundled locally and need no translation API or internet connection.

Menus, form labels and choices, standard statuses, safety action labels, and QR scanner controls are translated. Names, user-written descriptions, notice posters/content, and administrator-written safety instructions retain their original language. Certificate PDF files and SMS content retain their existing format. Administrators should write safety instructions in Malayalam when addressing Malayalam-speaking citizens.

For an existing installation, run `python manage.py migrate` to add the language preference. Translation strings are maintained in `portal/malayalam.json`; browser-only labels also use `static/js/language.js`. Tests include persistence, role boundaries, safe redirects, CSRF, form values and citizen page rendering.
