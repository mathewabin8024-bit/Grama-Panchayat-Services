(() => {
  const toggle = document.querySelector('[data-sidebar-toggle]');
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.querySelector('[data-close-sidebar]');
  function setMenu(open) {
    if (!sidebar || !toggle || !backdrop) return;
    sidebar.classList.toggle('is-open', open);
    backdrop.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', window.portalTranslate(open ? 'Close navigation' : 'Open navigation'));
  }
  toggle?.addEventListener('click', () => setMenu(!sidebar.classList.contains('is-open')));
  backdrop?.addEventListener('click', () => setMenu(false));
  document.addEventListener('keydown', event => { if (event.key === 'Escape') setMenu(false); });
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => { if (!window.confirm(form.dataset.confirm)) event.preventDefault(); });
  });
  const status = document.getElementById('id_status');
  function showScheduleFields() {
    ['id_assigned_to', 'id_scheduled_date'].forEach(id => {
      const field = document.getElementById(id);
      if (field && status) field.closest('.form-field').hidden = status.value !== 'scheduled';
    });
  }
  status?.addEventListener('change', showScheduleFields);
  showScheduleFields();
  const certificateType = document.getElementById('id_certificate_type');
  function updateCertificateFields() {
    if (!certificateType) return;
    const kind = certificateType.value;
    document.querySelectorAll('[data-certificate-types]').forEach(group => {
      const visible = group.dataset.certificateTypes.split(' ').includes(kind);
      group.hidden = !visible;
      const control = group.querySelector('input, select, textarea');
      if (control) {
        control.disabled = !visible;
        control.required = visible && group.dataset.conditionallyRequired === 'true';
      }
    });
    const labels = kind === 'birth'
      ? {id_subject_name: "Child's full name", id_event_date: 'Date of birth', id_event_place: 'Place of birth'}
      : {id_subject_name: "Deceased person's full name", id_event_date: 'Date of death', id_event_place: 'Place of death'};
    Object.entries(labels).forEach(([id, text]) => {
      const label = document.querySelector(`label[for="${id}"]`);
      if (label) label.textContent = window.portalTranslate(text) + ' *';
    });
  }
  certificateType?.addEventListener('change', updateCertificateFields);
  updateCertificateFields();
  const endpoint = document.body.dataset.notificationsUrl;
  async function refreshNotifications() {
    if (!endpoint || document.hidden) return;
    try {
      const response = await fetch(endpoint, {credentials: 'same-origin', headers: {'Accept': 'application/json'}});
      if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) return;
      const data = await response.json();
      const count = Number(data.unread_count) || 0;
      const previous = Number(document.querySelector('[data-unread-count]')?.textContent) || 0;
      document.querySelectorAll('[data-unread-count]').forEach(el => { el.textContent = String(count); el.hidden = count === 0; });
      document.querySelectorAll('[data-unread-dot]').forEach(el => { el.hidden = count === 0; });
      if (count > previous) {
        const announcement = document.querySelector('[data-notification-announcement]');
        if (announcement) announcement.textContent = document.documentElement.lang === "ml" ? `വായിക്കാത്ത ${count} അറിയിപ്പുകളുണ്ട്.` : `You have ${count} unread notifications.`;
      }
    } catch (_) { /* Preserve the last count during a temporary network failure. */ }
  }
  if (endpoint) {
    window.setInterval(refreshNotifications, 20000);
    document.addEventListener('visibilitychange', refreshNotifications);
  }
})();
