(() => {
 const region=document.getElementById('safety-banner-region');if(!region)return;
 async function refresh(){
  if(document.hidden)return;
  try {const res=await fetch('/safety-alerts/banner/',{credentials:'same-origin',cache:'no-store'});
   if(!res.ok || res.redirected)return;
   const html=await res.text();if(region.innerHTML.trim()!==html.trim())region.innerHTML=html;
  }catch(_){}
 }
 setInterval(refresh,15000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
})();
