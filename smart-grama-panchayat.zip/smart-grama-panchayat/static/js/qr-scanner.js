(() => {
  const start = document.getElementById('qr-start');
  if (!start) return;
  const stopButton = document.getElementById('qr-stop');
  const video = document.getElementById('qr-video');
  const canvas = document.getElementById('qr-canvas');
  const status = document.getElementById('qr-status');
  const fileInput = document.getElementById('qr-image');
  const ctx = canvas.getContext('2d', {willReadFrequently: true});
  let stream = null, timer = null, generation = 0;
  function stop() {
    generation++;
    clearTimeout(timer);
    if (stream) stream.getTracks().forEach(track => track.stop());
    stream = null; video.srcObject = null; video.hidden = true;
    start.disabled = false; stopButton.hidden = true;
  }
  function accept(text) {
    const uuid = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';
    let token = new RegExp('^' + uuid + '$', 'i').test(text.trim()) ? text.trim() : null;
    if (!token) {
      try {
        const url = new URL(text);
        const match = url.pathname.match(new RegExp('^/verify/(' + uuid + ')/?$', 'i'));
        if (['http:', 'https:'].includes(url.protocol) && match) token = match[1];
      } catch (_) { }
    }
    if (!token) {status.textContent = window.portalTranslate('This QR is not a certificate verification QR. Try the QR printed on your certificate.'); return false;}
    stop(); status.textContent = window.portalTranslate('QR found. Checking the certificate record…');
    // Always open our own verification route, never a QR-supplied external website.
    window.location.assign('/verify/' + token + '/');
    return true;
  }
  function decode(source, width, height) {
    const scale = Math.min(1, 1600 / Math.max(width, height));
    canvas.width = Math.round(width * scale); canvas.height = Math.round(height * scale);
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return jsQR(pixels.data, pixels.width, pixels.height, {inversionAttempts: 'attemptBoth'});
  }
  function tick() {
    if (!stream) return;
    if (video.readyState >= 2 && video.videoWidth) {
      const result = decode(video, video.videoWidth, video.videoHeight);
      if (result && accept(result.data)) return;
    }
    timer = setTimeout(tick, 180);
  }
  start.addEventListener('click', async () => {
    if (!navigator.mediaDevices?.getUserMedia) {status.textContent = window.portalTranslate('Camera unavailable here. Use HTTPS or localhost, or select a QR image below.'); return;}
    stop(); const attempt = generation; start.disabled = true; stopButton.hidden = false;
    status.textContent = window.portalTranslate('Allow camera access, then hold the certificate QR inside the camera view.');
    try {
      const candidate = await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}}, audio:false});
      if (attempt !== generation) {candidate.getTracks().forEach(track => track.stop()); return;}
      stream = candidate; video.srcObject = stream; video.hidden = false;
      await video.play(); tick();
    } catch (_) {stop(); status.textContent = window.portalTranslate('Could not open the camera. Check browser permission and camera availability, or choose a QR image.');}
  });
  stopButton.addEventListener('click', () => {stop(); status.textContent = window.portalTranslate('Camera stopped.');});
  fileInput.addEventListener('change', async () => {
    stop(); const file = fileInput.files[0]; if (!file) return;
    if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 10*1024*1024) {status.textContent = window.portalTranslate('Choose a PNG, JPEG or WebP image no larger than 10 MB.'); return;}
    status.textContent = window.portalTranslate('Reading QR image…');
    const image = new Image(), url = URL.createObjectURL(file);
    try {
      image.src = url; await image.decode();
      const result = decode(image, image.naturalWidth, image.naturalHeight);
      if (result) accept(result.data);
      else status.textContent = window.portalTranslate('No readable QR found. Crop closer to the QR, keep all four corners visible, and try again.');
    } catch (_) {status.textContent = window.portalTranslate('Could not read this image. Choose a clear screenshot or photo of the QR.');}
    finally {URL.revokeObjectURL(url); fileInput.value = '';}
  });
  window.addEventListener('pagehide', stop);
  document.addEventListener('visibilitychange', () => {if (document.hidden) stop();});
})();
