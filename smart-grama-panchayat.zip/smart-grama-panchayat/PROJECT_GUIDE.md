# Project guide

## Purpose and architecture

Smart Digital Grama Panchayat Services brings certificate applications, complaints and waste collection requests into one portal. The implementation follows the supplied MCA review presentation and adds runnable workflows, sample data and tests.

A browser sends requests to Django URLs and views. Views enforce authentication and record ownership, forms validate input, and the service layer commits workflow changes and notifications in a database transaction. Django ORM models work with SQLite for the local demonstration or MySQL when configured. Templates generate HTML and small JavaScript helpers handle navigation and notification polling.

```mermaid
flowchart LR
  Browser[Citizen / Official / Collector browser] --> Views[Django views and permission checks]
  Views --> Forms[Form validation]
  Forms --> Services[Atomic service workflows]
  Services --> ORM[Django ORM]
  ORM --> Database[(MySQL or SQLite)]
  Views --> Private[Authorized private document download]
  Views --> PDF[Certificate PDF and QR generation]
  QR[Public QR verification] --> Views
```

## Database design

| Model | Main fields | Relationships |
| --- | --- | --- |
| User | Username, password hash, name, email, staff flags | Django's built-in account model |
| Profile | Phone, address, ward, citizen/collector role | One profile per user |
| ServiceRequest | Reference, kind, status, title, applicant, address, document, dates, verification UUID | Belongs to a citizen; optional assigned collector |
| StatusUpdate | Previous status, new status, note, time | Belongs to a request; identifies the actor |
| Notification | Title, message, read flag, time | Belongs to a user; optional linked request |
| Announcement | Title, body, category, event date, venue, poster, published flag, time | Optional author |
| CertificateDocument | Original PDF bytes, SHA-256 fingerprint, issue snapshot | One per approved certificate |

The project uses one ServiceRequest table with a `kind` field. Certificate-only fields and collection-only fields remain blank for the other services. Shared ownership checks, status history and reports stay consistent. If future services need many separate fields, individual service tables could be introduced without changing the account model.

```mermaid
erDiagram
  USER ||--|| PROFILE : has
  USER ||--o{ SERVICE_REQUEST : submits
  USER o|--o{ SERVICE_REQUEST : collects
  SERVICE_REQUEST ||--o{ STATUS_UPDATE : records
  USER o|--o{ STATUS_UPDATE : performs
  USER ||--o{ NOTIFICATION : receives
  SERVICE_REQUEST o|--o{ NOTIFICATION : concerns
  USER o|--o{ ANNOUNCEMENT : writes
```

## Roles and permissions

- **Citizen:** register, update contact details, submit requests, read their own records and supporting files, cancel submitted or under-review requests, download approved certificates and read personal notifications.
- **Official:** an active Django staff account; review all requests, update their workflow, schedule collections, publish notices and export reports.
- **Collector:** an active account with collector profile role; view only assigned waste requests and mark a scheduled request collected.
- **Superuser:** administer accounts and roles in Django admin. Request and audit records there are read-only; service decisions use the portal workflow.

Backend views enforce these rules. Knowing another request's numeric URL does not grant access. Public registration and profile forms do not expose role or staff fields.

## Service workflows

| Service | Normal path | Other supported decisions |
| --- | --- | --- |
| Certificate | Submitted → Under review → Approved | Reject or cancel before approval; revoke after approval |
| Complaint | Submitted → Under review → In progress → Resolved | Reject or cancel before processing; reject while in progress |
| Waste collection | Submitted → Under review → Scheduled → Collected | Reject or cancel before scheduling; official can cancel a scheduled pickup |

Officials may approve a submitted certificate directly, resolve a submitted complaint directly, or schedule a submitted waste request directly. These shortcuts still create audit entries. Rejected, resolved, collected, cancelled and revoked records are terminal. An approved certificate can only transition to revoked.

Rejection and revocation require an explanation. Scheduling requires an active collector and a date that is today or later. Citizen preferred dates are limited to today through 90 days ahead. `transition_request()` locks the record, checks permissions and current state again, changes the status and writes history and notifications in one transaction.

## Certificate and document handling

The academic certificate categories are birth, death, residence, property ownership and general. Supporting documents are required for applications and optional for complaints. The form permits PDF, PNG and JPEG files up to 5 MB. Image contents are validated with Pillow and PDF uploads require a PDF header. This is file-type validation, not antivirus scanning.

Uploads have random filenames and no public media route. Each download checks ownership or official access. Passwords use Django's password hashing. Documents and database fields are not encrypted at rest by this project.

Approval records the issue time. Approval generates and stores a fixed original PDF, an issue snapshot and its SHA-256 fingerprint. The PDF is prominently marked as a demonstration. Its QR contains a verification URL with an unguessable UUID. The public page checks current database status and shows reference, certificate type, issue date and applicant initials only. Revocation immediately makes that URL invalid. QR verification checks current database status. The public page also compares an uploaded PDF fingerprint against the stored original to detect file changes without saving the upload. A copied QR does not prove an unchanged document, and this is not a cryptographic digital signature.

## Notifications and reports

Submission and status changes create database notifications for the citizen. Scheduling also notifies the assigned collector. The browser checks the unread count every 20 seconds while visible. The notification page shows the messages and lets the account mark its own messages read.

The dashboard counts actual stored records. Officials can inspect counts by service/status and export request summaries as CSV. CSV cells that could trigger spreadsheet formulas are escaped. The digital notice board supports poster images, categories, event dates and venues. Officials can edit notices, replace/remove posters, and publish or unpublish. Draft notices and their images are restricted to officials.

## Differences from the proposal

- The local demo starts with SQLite so no separate database service is required. MySQL connection settings and its driver requirements are supplied, but a live MySQL server was not available for integration testing here.
- Notifications are in-app with polling. An optional SMS outbox supports Traccar Android SIM sending or Twilio for safety alerts; gateway or account setup is required. Email, browser push and WebSockets are not included.
- The slides mention AES storage encryption. This implementation provides hashed passwords and access-controlled uploads; storage encryption needs additional deployment work.
- These certificates demonstrate the software workflow. There is no government integration, official digital signature, legal authorization or payment processing.
- The interface and PDF layout target English. Production localization and institution-specific certificate rules remain future work.

## Validation

The automated suite covers successful certificate submission, approval and PDF generation; complaint submission/resolution; waste submission/scheduling/collection; record and file privacy; forbidden role escalation; CSRF rejection; invalid status changes; revocation; upload limits; invalid collection dates; notification ownership; report access; and CSV formula protection.

See `VALIDATION.md` for the checks performed on this build. Run `manage.py test portal` after modifying workflow rules or permissions.

## Viva preparation

**1. Why Django?** It provides authentication, password hashing, CSRF middleware, form validation, an ORM, schema migrations and an administration interface. The project can concentrate on the service workflows.

**2. What does the service layer do?** It keeps transition permissions, allowed statuses, assignment rules, audit records and notifications together. A transaction ensures the database changes succeed or fail together.

**3. How are user records protected?** Queries filter to the signed-in citizen or assigned collector, while officials use a broader authorized query. Downloads use the same ownership checks.

**4. What does a QR code prove here?** It connects to a current approved application in this database. Uploading the original PDF additionally checks an exact fingerprint match. This does not provide a government signature or independently verify submitted evidence.

**5. What happens after revocation?** The status becomes revoked, the decision is audited and the applicant is notified. PDF downloading stops and the same verification URL reports invalid.

**6. Why separate preferred and scheduled dates?** Citizens request a convenient date, but officials need to confirm a feasible date and assign a collector. Keeping both fields preserves the original preference.

**7. How can the database be changed?** Environment variables select Django's MySQL backend. The same migrations create the schema. Existing SQLite records require a separate planned migration; changing a setting alone does not transfer them.

**8. What would you add before real deployment?** Institution-approved certificate requirements, real identity and government integrations, HTTPS hosting, protected backups, rate limiting, monitoring, storage protection, localization and appropriate notification delivery.

## Administrator-issued safety alerts

SafetyAlert records the affected area, target ward, action level, safe location, instructions, contact and issuing official. SafetyRecipient snapshots the targeted active citizen accounts and an optional acknowledgement timestamp. Issuance atomically creates the alert, recipients and linked notifications. Only officials can issue or close alerts. Closing records the actor, time and explanation and notifies the original recipients.

Citizens see only alerts addressed to them. Active warnings appear across their portal pages and refresh every 15 seconds while visible. Acknowledging reading does not hide the warning or report the person safe. Acknowledgement totals are shown to officials. No actual public alert is sent by the automated tests.

## QR scanner

The verification landing page decodes camera frames or a selected image with locally bundled jsQR. It accepts a UUID or a certificate verification path and navigates only to this portal's verification route. Camera tracks stop when scanning stops or the page is hidden. The database determines validity; decoding a QR alone never produces a valid result.

## SMS outbox

SafetySMS snapshots recipient numbers and message text in the same transaction as alert issuance. A separate worker claims pending records, sends through the configured provider and polls Twilio delivery receipts without requiring public hosting. Traccar acceptance remains submitted because this integration does not retrieve phone delivery receipts. Each row snapshots its backend so changing providers cannot resend old records. UI status distinguishes disabled/simulated, pending, submitted, delivered, failed, unknown, invalid, cancelled and expired outcomes. See SMS_SETUP.md for operation and limits.
