from django.contrib import admin
from django.urls import include, path

urlpatterns = [path('admin/', admin.site.urls), path('', include('portal.urls'))]
admin.site.site_header = 'Smart Grama administration'
admin.site.site_title = 'Smart Grama'
admin.site.index_title = 'User and system administration'
